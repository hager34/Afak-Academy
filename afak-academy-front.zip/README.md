# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## Afak Academy frontend

This project is a frontend-only, bilingual Arabic/English website. It does not connect to a database, authentication provider, payments, email delivery, or any other backend service.

### Edit academy content

- Edit services, academic fields, specializations, example requests, how-it-works steps, benefits, and FAQs in `src/content/services.ts` (add an entry to `fields` or its `specializations` array and pages, cards, and the request form update automatically). Edit contact placeholders in `src/content/site.ts`.
- The service request form posts through `api.submitServiceRequest` in `src/services/api.ts` (future `POST /service-requests`, using `VITE_API_BASE_URL`). File uploads are a placeholder until storage is connected.
- Keep sample or unverified details visibly labelled until academy staff approve real information.
- Shared interface pieces live in `src/components/afak/`; page files live in `src/routes/`.

### Connect the future AWS API

Create a local `.env` value (never commit secrets):

```sh
VITE_API_BASE_URL=https://your-api-id.execute-api.region.amazonaws.com
```

The browser-safe API contract and active mock handlers are in `src/services/api.ts`. Replace the mock method bodies with `fetch` calls only when AWS API Gateway is ready. `VITE_` variables are public: never place AWS credentials, SMTP passwords, database passwords, Cognito secrets, or other private keys in them.

The future AWS backend must validate every request again and configure CORS for `https://afakacademy.online` and `https://www.afakacademy.online`. CORS is not implemented in this frontend.

## Initial phase (minimal backend)

Afak Academy is a public informational website. It is **not** a web application: no accounts are needed.

**Live now (Lovable Cloud):**
- Service requests: the form on `/request` → server function `submitServiceRequest` (`src/lib/requests.functions.ts`) → full server validation (zod), email normalization, honeypot, rate limit (5/hour per IP, 5/day per email) → `service_requests` row. The request number `AFAK-YYYY-000001` is made by the database. The page then goes to `/request/success`.
- Double Opt-in newsletter (`src/lib/newsletter.functions.ts` + `newsletter.server.ts`): subscribe, confirm, resend-confirmation, get/update preferences, unsubscribe. Only SHA-256 token hashes are stored. Confirmation links expire after 48h, and resending creates a new link that replaces the old one. Confirming twice is safe. Responses never reveal whether an email exists. Every change is logged in `consent_events`.
- Pages: `/check-your-email`, `/confirm-subscription`, `/email-preferences`, `/unsubscribe`.
- The newsletter checkbox on the request form is optional and separate. People are only added to the newsletter after they confirm by email.

**Tables:** service_requests, newsletter_subscribers, newsletter_topics (editable), subscriber_topics, consent_events, email_outbox, email_events (future SES events), rate_limits. RLS is on and the public has no access to any table. All access goes through server functions. The academy reviews requests in the Cloud database view.

**Email outbox and Amazon SES:** each email is added to `email_outbox` as `PENDING`. Planned route: server function → AWS API Gateway → Lambda → SES. Set these Lovable secrets when ready: `AWS_EMAIL_API_URL`, `AWS_EMAIL_API_AUTH_TOKEN`, `AWS_EMAIL_WEBHOOK_SECRET`. Until they are set, jobs stay PENDING and the logs show a warning. When AWS accepts a job it is marked PROCESSING. It is marked SENT only after a verified SES delivery event, handled by a webhook that is still to be built. Addresses that bounce or complain become SUPPRESSED. Development builds show a test-only confirmation link, and production never does.

**Remaining AWS work:** domain, DKIM/SPF/DMARC, Custom MAIL FROM, SES production access, the email API + Lambda, the SES events webhook (fills email_events and suppresses addresses), and a retry job for PENDING/FAILED emails.

**Payments are intentionally postponed to a later phase.** Also postponed: student authentication, student dashboard, administrator dashboard, quotes, orders, file uploads, and learning-management features. `/portal` is a future placeholder: it is hidden from search engines and not linked anywhere on the site.

**Testing checklist:** AR/EN submission, required fields, contact consent, with/without newsletter, request numbers, rate limit, duplicate subscribe, confirm / invalid / expired / already confirmed, resend, preferences, unsubscribe, suppression, mobile/tablet/desktop, RTL/LTR.
