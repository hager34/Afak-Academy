# Afak Academy bilingual frontend

## Experience
- Build a polished Arabic-first academy site with a deep navy foundation, restrained violet accents, warm gold details, off-white reading surfaces, and an editorial learning-focused visual style.
- Support RTL Arabic and LTR English through a visible language control; all navigation, labels, forms, metadata, and sample content switch together.
- Add an original hero learning image, restrained iconography, visible keyboard focus, reduced-motion behavior, and responsive layouts for phone, tablet, and desktop.

## Pages and navigation
- Create dedicated routes for Home, Programs, Program Details, About, Contact, Join, Student Portal, Privacy, Terms, Cookies, Email Preferences, and the not-found experience.
- Use a shared announcement bar, site header, mobile menu, language switcher, footer, cookie preferences banner, and bilingual metadata.
- Keep every navigation target functional, with Programs linking to real mock detail pages and all primary actions leading to the appropriate route.

## Content and reusable interface
- Centralize bilingual academy copy, contact placeholders, programs, curriculum, FAQs, instructor placeholders, sample statistics, testimonials, and events in editable data files.
- Add reusable program cards, testimonial cards, FAQ accordion, form fields, alerts/toasts, skeletons, empty states, and error states.
- Clearly label invented statistics, testimonials, dates, prices, and instructor information as sample/editable content; avoid accreditation, partnership, credential, and outcome claims.

## Forms and frontend behavior
- Build newsletter, contact, and enrollment-interest forms with labels, keyboard support, inline validation, consent handling, loading feedback, and accessible success/error messages.
- Use local mock submissions only. No database, authentication, payment system, email service, server function, or secret will be added.
- Add program search plus category and level filters, curriculum and FAQ accordions, cookie preference controls, and a polished non-authenticated portal placeholder.

## Future AWS connection
- Add a centralized browser-safe API client that reads `VITE_API_BASE_URL` and exposes the requested newsletter, contact, enrollment, program, and future login methods.
- Keep a clearly isolated mock service as the active implementation, with comments marking where AWS API Gateway endpoints can replace it later.
- Document content editing and the future environment variable in the README; mention that CORS belongs in the future AWS backend rather than this frontend.

## SEO and quality checks
- Give each content route unique Arabic/English-aware title, description, Open Graph text, canonical path, `og:type`, and Twitter card metadata.
- Add Organization and Course structured-data placeholders without unverifiable claims, plus local favicon/social-image placeholders.
- Verify the main navigation, language direction, filters, accordions, forms, cookie banner, detail route, mobile menu, responsive layouts, and current preview diagnostics.

## Assumptions
- Arabic is the initial language; the selected language persists in browser storage only.
- Contact details, prices, people, dates, and counts remain visibly marked placeholders until academy staff replace them.
- The portal is informational only and will not include simulated sign-in fields.
