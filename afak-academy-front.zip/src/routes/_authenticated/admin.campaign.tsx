import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { getCampaignOverview, sendAfakTestCampaign } from "@/lib/campaign.functions";

export const Route = createFileRoute("/_authenticated/admin/campaign")({
  head: () => ({ meta: [
    { title: "Send test campaign | Afak Academy admin" },
    { name: "description", content: "Owner-only page to review and send the Afak Academy test email." },
    { property: "og:title", content: "Send test campaign — Afak Academy" },
    { property: "og:description", content: "Owner-only test campaign page." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex, nofollow" },
  ] }),
  component: CampaignPage,
});

function CampaignPage() {
  const fetchOverview = useServerFn(getCampaignOverview);
  const send = useServerFn(sendAfakTestCampaign);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["campaign-overview"], queryFn: () => fetchOverview(), retry: false });
  const [preview, setPreview] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [sending, setSending] = useState(false);

  if (q.isLoading) return <section className="mx-auto max-w-4xl px-5 py-14 text-sm text-muted-foreground">Loading…</section>;
  if (q.isError || !q.data) return <section className="mx-auto max-w-4xl px-5 py-14"><h1 className="font-display text-3xl">Not allowed</h1><p className="mt-3 text-sm text-muted-foreground">This page is only available to the project owner.</p></section>;
  const d = q.data;
  const alreadySent = d.log.filter((l) => l.status === "SENT").length;

  async function onSend() {
    setSending(true);
    const r = await send({ data: { confirm: true } }).catch(() => ({ ok: false as const, error: "SERVER_ERROR" }));
    setSending(false);
    setConfirmed(false);
    if (!r.ok) toast.error(r.error === "NOT_CONFIGURED" ? "Amazon SES keys are not configured yet." : "Sending failed.");
    else toast.success(r.results.map((x) => `${x.email}: ${x.status}`).join(" · ") || "No eligible recipients.");
    qc.invalidateQueries({ queryKey: ["campaign-overview"] });
  }

  return (
    <section className="mx-auto max-w-4xl px-5 py-14" dir="ltr">
      <h1 className="font-display text-4xl">Send test campaign</h1>
      <dl className="mt-8 grid gap-4 border border-border p-6 text-sm">
        <div><dt className="font-semibold">Subject</dt><dd dir="rtl" className="text-right">{d.subject}</dd></div>
        <div><dt className="font-semibold">Recipients (allowlist)</dt><dd><ul>{d.allowlist.map((e) => <li key={e}>{e} {d.recipients.includes(e) ? "✓ eligible" : "— not eligible"}</li>)}</ul></dd></div>
        <div><dt className="font-semibold">Eligible recipients</dt><dd>{d.recipients.length}</dd></div>
        {d.log.length > 0 && <div><dt className="font-semibold">Send log</dt><dd><ul>{d.log.map((l) => <li key={l.recipient_email}>{l.recipient_email}: {l.status}{l.safe_error_code ? ` (${l.safe_error_code})` : ""}</li>)}</ul></dd></div>}
      </dl>

      <Button variant="outline" className="mt-6" onClick={() => setPreview((p) => !p)}>{preview ? "Hide preview" : "Preview email"}</Button>
      {preview && <iframe title="Email preview" sandbox="" srcDoc={d.preview.html} className="mt-4 h-[640px] w-full border border-border bg-background" />}

      <div className="mt-8 flex items-start gap-3">
        <Checkbox id="final-confirm" checked={confirmed} onCheckedChange={(v) => setConfirmed(v === true)} disabled={d.recipients.length === 0 || alreadySent === d.recipients.length} />
        <Label htmlFor="final-confirm" className="leading-6">I confirm I want to send this email to the {d.recipients.length} recipient(s) listed above. Each person gets their own message; anyone already sent to is skipped.</Label>
      </div>
      <Button className="mt-4" disabled={!confirmed || sending} onClick={onSend}>{sending ? "Sending…" : "Send"}</Button>
    </section>
  );
}
