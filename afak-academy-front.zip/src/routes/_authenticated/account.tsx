import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { LogOut } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { getMyRequests } from "@/lib/account.functions";
import { useLanguage } from "@/components/afak/language";

export const Route = createFileRoute("/_authenticated/account")({
  head: () => ({ meta: [
    { title: "حسابي | أكاديمية آفاق" },
    { name: "description", content: "تابع طلبات الخدمة واحفظ بياناتك في أكاديمية آفاق." },
    { property: "og:title", content: "حسابي — أكاديمية آفاق" },
    { property: "og:description", content: "طلباتك وبياناتك في مكان واحد." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  component: AccountPage,
});

const statusLabel: Record<string, [string, string]> = {
  NEW: ["جديد — قيد المراجعة", "New — under review"],
  IN_REVIEW: ["قيد المراجعة", "In review"],
  CONTACTED: ["تم التواصل", "Contacted"],
  CLOSED: ["مغلق", "Closed"],
};

type Profile = { full_name: string; phone: string; whatsapp: string; country: string; time_zone: string };

function AccountPage() {
  const { user } = Route.useRouteContext();
  const { isArabic } = useLanguage();
  const L = (a: string, e: string) => (isArabic ? a : e);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fetchRequests = useServerFn(getMyRequests);
  const requests = useQuery({ queryKey: ["my-requests"], queryFn: () => fetchRequests() });
  const [profile, setProfile] = useState<Profile>({ full_name: "", phone: "", whatsapp: "", country: "", time_zone: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    supabase.from("profiles").select("full_name,phone,whatsapp,country,time_zone").eq("id", user.id).maybeSingle().then(({ data }) => {
      if (data) setProfile({ full_name: data.full_name ?? "", phone: data.phone ?? "", whatsapp: data.whatsapp ?? "", country: data.country ?? "", time_zone: data.time_zone ?? "" });
    });
  }, [user.id]);

  async function save(ev: FormEvent) {
    ev.preventDefault();
    setSaving(true);
    const clean = Object.fromEntries(Object.entries(profile).map(([k, v]) => [k, v.trim().slice(0, 120) || null]));
    const { error } = await supabase.from("profiles").upsert({ id: user.id, ...clean, preferred_language: isArabic ? "ar" : "en" });
    setSaving(false);
    if (error) toast.error(L("تعذّر الحفظ.", "Could not save.")); else toast.success(L("تم حفظ بياناتك.", "Details saved."));
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const field = (key: keyof Profile, label: string, ltr = false) => (
    <div className="grid gap-2"><Label htmlFor={`pf-${key}`}>{label}</Label><Input id={`pf-${key}`} dir={ltr ? "ltr" : undefined} maxLength={120} value={profile[key]} onChange={(e) => setProfile({ ...profile, [key]: e.target.value })} /></div>
  );

  return (
    <section className="mx-auto max-w-5xl px-5 py-14">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div><h1 className="font-display text-4xl">{L("حسابي", "My account")}</h1><p className="mt-2 text-sm text-muted-foreground" dir="ltr">{user.email}</p></div>
        <Button variant="outline" onClick={signOut}><LogOut /> {L("تسجيل الخروج", "Sign out")}</Button>
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <div className="flex items-center justify-between gap-3"><h2 className="font-display text-2xl">{L("طلباتي", "My requests")}</h2><Button asChild size="sm"><Link to="/request">{L("طلب جديد", "New request")}</Link></Button></div>
          {requests.isLoading ? <p className="mt-6 text-sm text-muted-foreground">{L("جارٍ التحميل…", "Loading…")}</p>
            : requests.isError ? <p className="mt-6 text-sm text-destructive">{L("تعذّر تحميل الطلبات.", "Could not load requests.")}</p>
            : !requests.data?.length ? <div className="mt-6 border border-dashed border-border p-6 text-sm leading-6 text-muted-foreground">{L("لا توجد طلبات بعد. الطلبات التي ترسلها وأنت مسجّل الدخول ستظهر هنا.", "No requests yet. Requests you send while signed in will appear here.")}</div>
            : <ul className="mt-6 grid gap-3">{requests.data.map((r) => (
                <li key={r.id} className="border border-border p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-semibold" dir="ltr">{r.request_number}</span><span className="rounded-full bg-muted px-3 py-1 text-xs font-semibold">{(statusLabel[r.status] ?? [r.status, r.status])[isArabic ? 0 : 1]}</span></div>
                  <p className="mt-2 text-sm">{r.title || r.course_or_subject || r.service_type}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{L("الموعد النهائي", "Deadline")}: <span dir="ltr">{r.deadline}</span> · {L("أُرسل", "Sent")}: <span dir="ltr">{r.created_at.slice(0, 10)}</span></p>
                </li>))}</ul>}
        </div>
        <form onSubmit={save} className="grid content-start gap-4 border border-border p-6">
          <h2 className="font-display text-2xl">{L("بياناتي", "My details")}</h2>
          <p className="text-xs leading-5 text-muted-foreground">{L("تُستخدم لتعبئة نموذج الطلب تلقائياً.", "Used to fill in the request form for you.")}</p>
          {field("full_name", L("الاسم الكامل", "Full name"))}
          {field("phone", L("الهاتف", "Phone"), true)}
          {field("whatsapp", L("واتساب", "WhatsApp"), true)}
          {field("country", L("الدولة", "Country"))}
          {field("time_zone", L("المنطقة الزمنية", "Time zone"), true)}
          <Button type="submit" disabled={saving}>{L("حفظ", "Save")}</Button>
        </form>
      </div>
    </section>
  );
}
