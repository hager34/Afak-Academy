import { createFileRoute } from "@tanstack/react-router";
import { RequestForm } from "@/components/afak/request-form";
import { useLanguage } from "@/components/afak/language";
import { seo } from "@/lib/seo";

type Search = { service?: string | undefined; field?: string | undefined; specialization?: string | undefined };
const str = (v: unknown) => (typeof v === "string" && v.length < 80 ? v : undefined);

export const Route = createFileRoute("/request")({
  validateSearch: (s: Record<string, unknown>): Search => ({ service: str(s["service"]), field: str(s["field"]), specialization: str(s["specialization"]) }),
  head: () => seo("/request", "اطلب خدمة | أكاديمية آفاق", "قدّم طلب دعم في المقررات الجامعية أو المشروعات أو العروض التقديمية واحصل على خطة مخصصة."),
  component: Page,
});

function Page() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  const search = Route.useSearch();
  return <>
    <section className="bg-brand-navy py-16 text-brand-paper"><div className="mx-auto max-w-4xl px-5">
      <h1 className="font-display text-4xl md:text-5xl">{L("اطلب خدمة", "Request a Service")}</h1>
      <p className="mt-4 max-w-2xl leading-8 text-brand-paper/75">{L("سبع خطوات قصيرة تساعدنا على فهم احتياجك وإعداد خطة مخصصة لك.", "Seven short steps help us understand your needs and prepare a customized plan.")}</p>
    </div></section>
    <section className="mx-auto max-w-4xl px-5 py-14"><div className="border border-border bg-card p-6 md:p-10">
      <RequestForm key={`${search.service}-${search.field}-${search.specialization}`} initial={search} />
    </div></section>
  </>;
}
