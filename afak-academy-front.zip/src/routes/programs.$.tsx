import { createFileRoute, redirect } from "@tanstack/react-router";

// Obsolete program detail URLs redirect to services.
export const Route = createFileRoute("/programs/$")({
  beforeLoad: () => { throw redirect({ to: "/services", statusCode: 301 }); },
});
