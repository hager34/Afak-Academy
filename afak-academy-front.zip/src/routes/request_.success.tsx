import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/afak/language";
import { DevNotice, StatusPanel } from "@/components/afak/status-panel";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/request_/success")({
  head: () => seo("/request/success", "تم استلام طلبك | أكاديمية آفاق", "تأكيد استلام طلب الخدمة لدى أكاديمية آفاق.", { noindex: true }),
  component: Page,
});

type Last = { n: string; e: boolean; nl: boolean; dev?: string };

function Page() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  const [last, setLast] = useState<Last | null | undefined>(undefined);
  useEffect(() => {
    try { const raw = sessionStorage.getItem("afak-last-request"); setLast(raw ? (JSON.parse(raw) as Last) : null); } catch { setLast(null); }
  }, []);
  if (last === undefined) return <StatusPanel tone="loading" title={L("جارٍ التحميل…", "Loading…")} />;
  return (
    <StatusPanel tone="success" title={L("تم استلام طلبك بنجاح", "Your request has been received")}>
      {last && <p className="text-foreground">{L("رقم الطلب", "Request number")}: <strong dir="ltr" className="font-mono text-lg">{last.n}</strong></p>}
      <p>{L("تم استلام طلبك بنجاح. سيقوم فريقنا بمراجعة التفاصيل والتواصل معك عبر وسيلة التواصل المفضلة.", "Your request has been received successfully. Our team will review the details and contact you using your preferred contact method.")}</p>
      <p>{L("إرسال الطلب لا يترتب عليه أي التزام فوري بالدفع؛ سنتواصل معك قبل مناقشة التكلفة.", "Submitting a request does not create an immediate payment obligation; we will contact you before discussing pricing.")}</p>
      {last && !last.e && <p className="text-sm">{L("تم حفظ طلبك بنجاح. سيتم تفعيل إرسال البريد الإلكتروني بعد ربط نظام البريد الخاص بالأكاديمية.", "Your request has been stored successfully. Email delivery will be enabled after the academy’s email system is connected.")}</p>}
      {last?.nl && <p className="text-sm">{L("طلبت الاشتراك في النشرة البريدية؛ لن يتم تفعيله إلا بعد تأكيده من الرابط الذي سنرسله إلى بريدك.", "You asked to join the newsletter; it only becomes active after you confirm via the link we email you.")}</p>}
      <DevNotice url={last?.dev} label={L("رابط تأكيد للتطوير فقط:", "Development-only confirmation link:")} />
      <div className="mt-2 flex flex-wrap justify-center gap-3">
        <Button asChild><Link to="/">{L("العودة للرئيسية", "Return to Home")}</Link></Button>
        <Button asChild variant="outline"><Link to="/contact">{L("تواصل معنا", "Contact us")}</Link></Button>
      </div>
    </StatusPanel>
  );
}
