import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LoaderCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useLanguage } from "@/components/afak/language";
import { StatusPanel } from "@/components/afak/status-panel";
import { api } from "@/services/api";
import { seo } from "@/lib/seo";

const tok = (v: unknown) => (typeof v === "string" && v.length <= 100 ? v : undefined);
export const Route = createFileRoute("/email-preferences")({
  validateSearch: (s: Record<string, unknown>): { token?: string | undefined } => ({ token: tok(s["token"]) }),
  head: () => seo("/email-preferences", "تفضيلات البريد | أكاديمية آفاق", "اختر مواضيع رسائل أكاديمية آفاق أو ألغِ اشتراكك.", { noindex: true }),
  component: Page,
});

type Topic = { slug: string; name_ar: string; name_en: string; subscribed: boolean };
type S = { k: "loading" } | { k: "missing" } | { k: "invalid" } | { k: "network" } | { k: "ok"; status: string; email: string; topics: Topic[]; lang: "ar" | "en" };

function Page() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  const { token } = Route.useSearch();
  const [s, setS] = useState<S>({ k: "loading" }); const [busy, setBusy] = useState(false); const [saved, setSaved] = useState(false);
  useEffect(() => {
    if (!token) { setS({ k: "missing" }); return; }
    api.getPreferences(token).then((r) => setS(r.status === "ok" ? { k: "ok", status: r.subscriberStatus, email: r.maskedEmail, topics: r.topics, lang: r.language === "en" ? "en" : "ar" } : { k: "invalid" })).catch(() => setS({ k: token.length < 20 ? "invalid" : "network" }));
  }, [token]);

  if (s.k === "loading") return <StatusPanel tone="loading" title={L("جارٍ تحميل تفضيلاتك…", "Loading your preferences…")} />;
  if (s.k === "missing") return <StatusPanel tone="info" title={L("تفضيلات البريد", "Email preferences")}><p>{L("استخدم رابط «إدارة التفضيلات» الموجود في أي رسالة من آفاق للوصول إلى إعداداتك بأمان، دون الحاجة إلى حساب.", "Use the “Manage preferences” link in any Afak email to reach your settings securely — no account needed.")}</p><Button asChild variant="outline"><Link to="/">{L("العودة للرئيسية", "Back to home")}</Link></Button></StatusPanel>;
  if (s.k === "invalid") return <StatusPanel tone="warning" title={L("رابط غير صالح", "Invalid link")}><p>{L("لم نتمكن من التعرف على هذا الرابط.", "We couldn't recognise this link.")}</p></StatusPanel>;
  if (s.k === "network") return <StatusPanel tone="warning" title={L("تعذّر الاتصال", "Network error")}><p>{L("أعد تحميل الصفحة.", "Please reload the page.")}</p></StatusPanel>;

  const subscribed = s.status === "SUBSCRIBED";
  async function save() {
    if (s.k !== "ok" || !token) return;
    setBusy(true);
    try {
      const r = await api.updatePreferences({ token, topics: s.topics.filter((t) => t.subscribed).map((t) => t.slug), language: s.lang });
      if (r.status === "saved") { setSaved(true); toast.success(L("تم حفظ التفضيلات", "Preferences saved")); } else toast.error(L("تعذّر الحفظ", "Could not save"));
    } catch { toast.error(L("خطأ في الشبكة", "Network error")); } finally { setBusy(false); }
  }
  return (
    <section className="mx-auto max-w-2xl px-5 py-20">
      <h1 className="font-display text-4xl">{L("تفضيلات البريد", "Email preferences")}</h1>
      <p className="mt-3 text-muted-foreground" dir="auto">{s.email}</p>
      {!subscribed ? (
        <div className="mt-8 border border-border p-6"><p>{s.status === "PENDING" ? L("اشتراكك بانتظار التأكيد.", "Your subscription is awaiting confirmation.") : L("أنت غير مشترك حالياً. لإعادة الاشتراك استخدم نموذج النشرة وأكّد من الرابط الجديد.", "You are not currently subscribed. To resubscribe, use the newsletter form and confirm via the new link.")}</p></div>
      ) : (
        <div className="mt-8 grid gap-6 border border-border bg-card p-6">
          <fieldset><legend className="font-bold">{L("المواضيع", "Topics")}</legend>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">{s.topics.map((t) => (
              <div key={t.slug} className="flex items-center gap-3"><Checkbox id={`tp-${t.slug}`} checked={t.subscribed} onCheckedChange={(v) => { setSaved(false); setS({ ...s, topics: s.topics.map((x) => x.slug === t.slug ? { ...x, subscribed: v === true } : x) }); }} /><label htmlFor={`tp-${t.slug}`} className="text-sm">{isArabic ? t.name_ar : t.name_en}</label></div>
            ))}</div>
          </fieldset>
          <div className="grid gap-2"><label htmlFor="pref-lang" className="text-sm font-bold">{L("لغة الرسائل", "Email language")}</label>
            <select id="pref-lang" className="h-11 rounded-md border border-input bg-background px-3 text-sm" value={s.lang} onChange={(e) => { setSaved(false); setS({ ...s, lang: e.target.value === "en" ? "en" : "ar" }); }}><option value="ar">العربية</option><option value="en">English</option></select></div>
          {saved && <p role="status" className="text-sm text-brand-teal">{L("تم حفظ تفضيلاتك.", "Your preferences have been saved.")}</p>}
          <div className="flex flex-wrap justify-between gap-3">
            <Button onClick={save} disabled={busy}>{busy && <LoaderCircle className="animate-spin" />}{L("حفظ التفضيلات", "Save preferences")}</Button>
            <Button asChild variant="outline"><Link to="/unsubscribe" search={{ token }}>{L("إلغاء الاشتراك من كل الرسائل", "Unsubscribe from all")}</Link></Button>
          </div>
        </div>
      )}
    </section>
  );
}
