import { createFileRoute, redirect } from "@tanstack/react-router";

// Obsolete URL: programs were replaced by services.
export const Route = createFileRoute("/programs")({
  beforeLoad: () => { throw redirect({ to: "/services", statusCode: 301 }); },
});
