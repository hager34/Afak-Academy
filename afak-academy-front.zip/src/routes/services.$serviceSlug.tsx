import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Check, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldCard } from "@/components/afak/cards";
import { ServiceIcon } from "@/components/afak/icons";
import { SectionHeading } from "@/components/afak/shared";
import { useLanguage } from "@/components/afak/language";
import { fields, getService } from "@/content/services";
import { t } from "@/content/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/services/$serviceSlug")({
  loader: ({ params }) => { const service = getService(params.serviceSlug); if (!service) throw notFound(); return { slug: service.slug }; },
  head: ({ loaderData }) => {
    const s = loaderData ? getService(loaderData.slug) : undefined;
    if (!s) return { meta: [{ title: "الخدمة غير موجودة | أكاديمية آفاق" }, { name: "robots", content: "noindex" }] };
    return seo(`/services/${s.slug}`, `${s.title.ar} | ${s.title.en} — أكاديمية آفاق`, s.short.ar);
  },
  component: ServicePage,
});

function ServicePage() {
  const { slug } = Route.useLoaderData(); const s = getService(slug)!;
  const { lang, isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  return <>
    <section className="bg-brand-navy py-20 text-brand-paper"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <Link to="/services" className="text-sm text-brand-paper/70 hover:text-brand-gold">{L("← كل الخدمات", "← All services")}</Link>
      <span className="mt-6 grid size-14 place-items-center rounded-full bg-brand-paper/10 text-brand-gold"><ServiceIcon icon={s.icon} className="size-7" /></span>
      <h1 className="mt-5 max-w-3xl font-display text-4xl leading-tight md:text-6xl">{t(s.title, lang)}</h1>
      <p className="mt-5 max-w-3xl text-lg leading-8 text-brand-paper/75">{t(s.intro, lang)}</p>
      <Button asChild size="lg" variant="gold" className="mt-8"><Link to="/request" search={{ service: s.slug }}>{t(s.cta, lang)}</Link></Button>
    </div></section>
    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
      <SectionHeading eyebrow={L("ما تتضمنه الخدمة", "What’s included")} title={L("اختر ما يناسبك أو اجمع بين أكثر من عنصر", "Pick what fits, or combine several")} />
      <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{s.items.map((i) => <li key={i.en} className="flex gap-3 border border-border p-4"><Check className="mt-0.5 size-5 shrink-0 text-brand-violet" />{t(i, lang)}</li>)}</ul>
      {s.note && <p className="mt-10 flex gap-3 border-s-4 border-brand-gold bg-brand-paper p-6 leading-7"><ShieldCheck className="mt-1 size-6 shrink-0 text-brand-violet" />{t(s.note, lang)}</p>}
    </section>
    <section className="bg-brand-paper py-20"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <SectionHeading eyebrow={L("متاحة في", "Available in")} title={L("المجالات الأكاديمية", "Academic fields")} />
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">{fields.map((f) => <FieldCard key={f.slug} field={f} />)}</div>
    </div></section>
  </>;
}
