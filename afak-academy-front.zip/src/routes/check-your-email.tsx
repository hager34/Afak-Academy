import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { LoaderCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLanguage } from "@/components/afak/language";
import { DevNotice, StatusPanel } from "@/components/afak/status-panel";
import { api } from "@/services/api";
import { newsletterSchema } from "@/lib/validation";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/check-your-email")({
  head: () => seo("/check-your-email", "تحقق من بريدك | أكاديمية آفاق", "أكّد اشتراكك في نشرة أكاديمية آفاق من الرابط المرسل إلى بريدك.", { noindex: true }),
  component: Page,
});

function Page() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  const [dev, setDev] = useState<string | undefined>();
  const [email, setEmail] = useState(""); const [busy, setBusy] = useState(false);
  useEffect(() => { setDev(sessionStorage.getItem("afak-dev-confirm") ?? undefined); }, []); // dev-only value; never set in production
  async function resend(e: FormEvent) {
    e.preventDefault();
    const p = newsletterSchema.safeParse({ email });
    if (!p.success) { toast.error(L("أدخل بريداً صحيحاً", "Enter a valid email")); return; }
    setBusy(true);
    try {
      const r = await api.resendConfirmation({ email: p.data.email, language: isArabic ? "ar" : "en" });
      if (!r.ok) toast.error(L("محاولات كثيرة، حاول لاحقاً.", "Too many attempts, try later."));
      else { toast.success(L("إن كان هناك اشتراك بانتظار التأكيد، فسيصلك رابط جديد.", "If a subscription is awaiting confirmation, a new link is on its way.")); if (r.devConfirmUrl) setDev(r.devConfirmUrl); }
    } catch { toast.error(L("خطأ في الشبكة", "Network error")); } finally { setBusy(false); }
  }
  return (
    <StatusPanel tone="info" title={L("تحقق من بريدك الإلكتروني", "Check your email")}>
      <p>{L("إذا كان العنوان صحيحاً، فسنرسل رابط تأكيد. لن يبدأ اشتراكك إلا بعد الضغط عليه. الرابط صالح لمدة ٤٨ ساعة.", "If the address is valid, we will send a confirmation link. Your subscription only starts after you click it. The link is valid for 48 hours.")}</p>
      <p className="text-sm">{L("ملاحظة: سيتم تفعيل إرسال البريد بعد ربط نظام البريد الخاص بالأكاديمية.", "Note: email delivery will be enabled once the academy’s email system is connected.")}</p>
      <DevNotice url={dev} label={L("رابط تأكيد للتطوير فقط:", "Development-only confirmation link:")} />
      <form onSubmit={resend} className="mt-2 flex gap-2 text-start">
        <label htmlFor="resend-email" className="sr-only">{L("البريد الإلكتروني", "Email")}</label>
        <Input id="resend-email" type="email" maxLength={255} placeholder="name@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
        <Button type="submit" variant="outline" disabled={busy}>{busy && <LoaderCircle className="animate-spin" />}{L("إعادة الإرسال", "Resend")}</Button>
      </form>
      <Button asChild variant="link"><Link to="/">{L("العودة للرئيسية", "Back to home")}</Link></Button>
    </StatusPanel>
  );
}
