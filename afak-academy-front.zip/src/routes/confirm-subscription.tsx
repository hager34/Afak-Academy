import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/afak/language";
import { StatusPanel } from "@/components/afak/status-panel";
import { api } from "@/services/api";
import { seo } from "@/lib/seo";

const tok = (v: unknown) => (typeof v === "string" && v.length <= 100 ? v : undefined);
export const Route = createFileRoute("/confirm-subscription")({
  validateSearch: (s: Record<string, unknown>): { token?: string | undefined } => ({ token: tok(s["token"]) }),
  head: () => seo("/confirm-subscription", "تأكيد الاشتراك | أكاديمية آفاق", "تأكيد الاشتراك في النشرة البريدية لأكاديمية آفاق.", { noindex: true }),
  component: Page,
});

type S = "loading" | "confirmed" | "already_confirmed" | "invalid" | "expired" | "missing" | "network" | "rate_limited";

function Page() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  const { token } = Route.useSearch();
  const [state, setState] = useState<S>("loading"); const [pref, setPref] = useState<string>();
  useEffect(() => {
    if (!token) { setState("missing"); return; }
    let live = true;
    api.confirmNewsletter(token).then((r) => { if (!live) return; setState(r.status); if ("preferencesToken" in r && r.preferencesToken) setPref(r.preferencesToken); }).catch(() => live && setState(token.length < 20 ? "invalid" : "network"));
    return () => { live = false; };
  }, [token]);

  const home = <Button asChild variant="outline"><Link to="/">{L("العودة للرئيسية", "Back to home")}</Link></Button>;
  const retry = <Button asChild><Link to="/check-your-email">{L("طلب رابط جديد", "Request a new link")}</Link></Button>;
  switch (state) {
    case "loading": return <StatusPanel tone="loading" title={L("جارٍ تأكيد اشتراكك…", "Confirming your subscription…")} />;
    case "confirmed": return <StatusPanel tone="success" title={L("تم تأكيد اشتراكك", "Subscription confirmed")}><p>{L("شكراً! ستصلك التحديثات التعليمية وإعلانات الأكاديمية. يمكنك تعديل تفضيلاتك أو إلغاء الاشتراك في أي وقت.", "Thank you! You will receive educational updates and academy announcements. You can change preferences or unsubscribe any time.")}</p><div className="flex flex-wrap justify-center gap-3">{pref && <Button asChild><Link to="/email-preferences" search={{ token: pref }}>{L("إدارة التفضيلات", "Manage preferences")}</Link></Button>}{home}</div></StatusPanel>;
    case "already_confirmed": return <StatusPanel tone="success" title={L("اشتراكك مؤكد بالفعل", "Already confirmed")}><p>{L("لا حاجة لأي إجراء إضافي.", "No further action is needed.")}</p>{home}</StatusPanel>;
    case "expired": return <StatusPanel tone="warning" title={L("انتهت صلاحية الرابط", "This link has expired")}><p>{L("روابط التأكيد صالحة لمدة ٤٨ ساعة. اطلب رابطاً جديداً.", "Confirmation links are valid for 48 hours. Request a new one.")}</p>{retry}</StatusPanel>;
    case "missing": return <StatusPanel tone="warning" title={L("الرابط غير مكتمل", "Missing confirmation token")}><p>{L("افتح الرابط كاملاً كما ورد في رسالة التأكيد.", "Open the full link exactly as it appears in the confirmation email.")}</p>{retry}</StatusPanel>;
    case "network": return <StatusPanel tone="warning" title={L("تعذّر الاتصال", "Network error")}><p>{L("تحقق من اتصالك ثم أعد تحميل الصفحة.", "Check your connection and reload the page.")}</p>{home}</StatusPanel>;
    case "rate_limited": return <StatusPanel tone="warning" title={L("محاولات كثيرة", "Too many attempts")}><p>{L("انتظر قليلاً ثم حاول مجدداً.", "Please wait a moment and try again.")}</p>{home}</StatusPanel>;
    default: return <StatusPanel tone="warning" title={L("رابط غير صالح", "Invalid link")}><p>{L("قد يكون الرابط مستخدماً في طلب أحدث أو غير صحيح.", "The link may have been replaced by a newer one or is incorrect.")}</p>{retry}</StatusPanel>;
  }
}
