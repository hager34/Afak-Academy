import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { ServiceCard } from "@/components/afak/cards";
import { FAQList, SectionHeading } from "@/components/afak/shared";
import { useLanguage } from "@/components/afak/language";
import { generalFaqs, services } from "@/content/services";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/services/")({
  head: () => seo("/services", "خدمات أكاديمية آفاق | المقررات والمشروعات والعروض", "تعرّف على خدمات آفاق: شرح المقررات الجامعية، ودعم المشروعات، والعروض التقديمية الأكاديمية والمهنية."),
  component: ServicesPage,
});

function ServicesPage() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  return <>
    <section className="bg-brand-navy py-20 text-brand-paper"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <p className="text-sm font-bold text-brand-gold">{L("الخدمات", "Services")}</p>
      <h1 className="mt-4 max-w-3xl font-display text-4xl leading-tight md:text-6xl">{L("دعم أكاديمي بثلاث صيغ واضحة", "Academic support in three clear forms")}</h1>
      <p className="mt-5 max-w-2xl text-lg leading-8 text-brand-paper/75">{L("كل خدمة متاحة عبر مجالاتنا الأكاديمية المختلفة، وتُصمم تفاصيلها حسب طلبك.", "Every service is available across our academic fields, with details tailored to your request.")}</p>
    </div></section>
    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8"><div className="grid gap-5 lg:grid-cols-3">{services.map((s, i) => <ServiceCard key={s.slug} service={s} index={i} />)}</div></section>
    <section className="mx-auto grid max-w-7xl gap-12 px-5 pb-24 lg:grid-cols-2 lg:px-8">
      <SectionHeading eyebrow={L("أسئلة شائعة", "FAQ")} title={L("قبل أن تبدأ", "Before you start")} />
      <div><FAQList items={generalFaqs} /><Button asChild className="mt-8"><Link to="/request">{L("اطلب خدمة", "Request a Service")}</Link></Button></div>
    </section>
  </>;
}
