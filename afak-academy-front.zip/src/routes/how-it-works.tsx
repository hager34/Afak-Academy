import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FAQList } from "@/components/afak/shared";
import { useLanguage } from "@/components/afak/language";
import { generalFaqs, howItWorks } from "@/content/services";
import { t } from "@/content/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/how-it-works")({
  head: () => seo("/how-it-works", "كيف نعمل | أكاديمية آفاق", "خمس خطوات لطلب دعم أكاديمي مخصص: اختر المجال والتخصص والخدمة، وصف احتياجك، واستلم خطة تناسبك."),
  component: Page,
});

function Page() {
  const { lang, isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  return <>
    <section className="bg-brand-paper py-20"><div className="mx-auto max-w-4xl px-5">
      <p className="text-sm font-bold text-brand-violet">{L("كيف نعمل", "How it works")}</p>
      <h1 className="mt-4 font-display text-4xl leading-tight md:text-6xl">{L("من طلبك إلى خطة واضحة", "From your request to a clear plan")}</h1>
    </div></section>
    <section className="mx-auto max-w-4xl px-5 py-20">
      <ol className="relative grid gap-10 border-s-2 border-border ps-8">
        {howItWorks.map((s, i) => <li key={s.title.en} className="relative"><span className="absolute -start-[3.1rem] grid size-10 place-items-center rounded-full bg-brand-navy font-display text-brand-gold">{isArabic ? (i + 1).toLocaleString("ar-EG") : i + 1}</span><h2 className="font-display text-2xl">{t(s.title, lang)}</h2><p className="mt-2 leading-7 text-muted-foreground">{t(s.text, lang)}</p></li>)}
      </ol>
      <p className="mt-14 flex gap-3 border-s-4 border-brand-gold bg-brand-paper p-6 leading-7"><ShieldCheck className="mt-1 size-6 shrink-0 text-brand-violet" />{L("نركز على الفهم والعمل الأصيل، ولا نضمن درجات أو نتائج. تُحدد التكلفة بعد مراجعة الطلب، ولا يتم الدفع عبر الموقع حالياً.", "We focus on understanding and original work, and we do not guarantee grades or results. Costs are set after review; no payment is collected on the website for now.")}</p>
      <div className="mt-14"><FAQList items={generalFaqs} /></div>
      <Button asChild size="lg" className="mt-10"><Link to="/request">{L("ابدأ طلبك", "Start Your Request")}</Link></Button>
    </section>
  </>;
}
