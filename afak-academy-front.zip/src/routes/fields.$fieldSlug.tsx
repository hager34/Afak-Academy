import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { MessageSquareQuote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { FieldIcon, ServiceIcon } from "@/components/afak/icons";
import { FAQList, SectionHeading } from "@/components/afak/shared";
import { useLanguage } from "@/components/afak/language";
import { getField, services } from "@/content/services";
import { t } from "@/content/site";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/fields/$fieldSlug")({
  loader: ({ params }) => { const f = getField(params.fieldSlug); if (!f) throw notFound(); return { slug: f.slug }; },
  head: ({ loaderData }) => {
    const f = loaderData ? getField(loaderData.slug) : undefined;
    if (!f) return { meta: [{ title: "المجال غير موجود | أكاديمية آفاق" }, { name: "robots", content: "noindex" }] };
    return seo(`/fields/${f.slug}`, `${f.name.ar} | ${f.name.en} — أكاديمية آفاق`, f.description.ar);
  },
  component: FieldPage,
});

function FieldPage() {
  const { slug } = Route.useLoaderData(); const f = getField(slug)!;
  const { lang, isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  return <>
    <section className="bg-brand-navy py-20 text-brand-paper"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <Link to="/fields" className="text-sm text-brand-paper/70 hover:text-brand-gold">{L("← كل المجالات", "← All fields")}</Link>
      <span className="mt-6 grid size-14 place-items-center rounded-md bg-brand-paper/10 text-brand-gold"><FieldIcon icon={f.icon} className="size-7" /></span>
      <h1 className="mt-5 font-display text-4xl md:text-6xl">{t(f.name, lang)}</h1>
      <p className="mt-5 max-w-3xl text-lg leading-8 text-brand-paper/75">{t(f.description, lang)}</p>
      <div className="mt-8 flex flex-wrap gap-3">{services.map((s) => <Button key={s.slug} asChild variant={s.slug === "courses" ? "gold" : "paper"}><Link to="/request" search={{ service: s.slug, field: f.slug }}><ServiceIcon icon={s.icon} />{t(s.cta, lang)}</Link></Button>)}</div>
    </div></section>

    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
      <SectionHeading eyebrow={L("التخصصات", "Specializations")} title={L("اختر تخصصك وابدأ الطلب مباشرة", "Pick your specialization and start right away")} />
      <div className="mt-10 grid gap-4 md:grid-cols-2">
        {f.specializations.map((sp) => (
          <article key={sp.slug} className="border border-border p-5">
            <h3 className="font-display text-lg">{t(sp.name, lang)}</h3>
            <div className="mt-4 flex flex-wrap gap-2">
              {services.map((s) => <Button key={s.slug} asChild size="sm" variant="outline"><Link to="/request" search={{ service: s.slug, field: f.slug, specialization: sp.slug }} aria-label={`${t(s.cta, lang)} — ${t(sp.name, lang)}`}><ServiceIcon icon={s.icon} />{t(s.cta, lang)}</Link></Button>)}
            </div>
          </article>
        ))}
      </div>
    </section>

    <section className="bg-brand-paper py-20"><div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-2 lg:px-8">
      <div>
        <SectionHeading eyebrow={L("الخدمات المتاحة", "Available services")} title={L("ما يمكننا مساعدتك فيه", "How we can help")} />
        <div className="mt-8 grid gap-3">{services.map((s) => <Link key={s.slug} to="/services/$serviceSlug" params={{ serviceSlug: s.slug }} className="flex gap-4 border border-border bg-background p-5 hover:border-brand-violet"><ServiceIcon icon={s.icon} className="size-6 shrink-0 text-brand-violet" /><span><strong className="block">{t(s.title, lang)}</strong><span className="text-sm text-muted-foreground">{t(s.short, lang)}</span></span></Link>)}</div>
      </div>
      <div>
        <SectionHeading eyebrow={L("أمثلة", "Examples")} title={L("طلبات توضيحية", "Example requests")} description={L("أمثلة للتوضيح فقط.", "Illustrative examples only.")} />
        <ul className="mt-8 grid gap-3">{f.examples.map((e) => <li key={e.en} className="flex gap-3 border border-border bg-background p-4"><MessageSquareQuote className="size-5 shrink-0 text-brand-gold" />“{t(e, lang)}”</li>)}</ul>
      </div>
    </div></section>

    <section className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-2 lg:px-8">
      <SectionHeading eyebrow={L("أسئلة شائعة", "FAQ")} title={t(f.name, lang)} />
      <div><FAQList items={f.faqs} /><Button asChild size="lg" className="mt-8"><Link to="/request" search={{ field: f.slug }}>{L("ابدأ طلبك", "Start Your Request")}</Link></Button></div>
    </section>
  </>;
}
