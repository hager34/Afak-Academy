import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { FieldCard } from "@/components/afak/cards";
import { useLanguage } from "@/components/afak/language";
import { fields } from "@/content/services";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/fields/")({
  head: () => seo("/fields", "المجالات الأكاديمية | أكاديمية آفاق", "الهندسة، الطب والعلوم الصحية، علوم الحاسب، إدارة الأعمال، والعلوم الطبيعية — اختر مجالك وتخصصك."),
  component: FieldsPage,
});

function FieldsPage() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  return <>
    <section className="bg-brand-paper py-20"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <p className="text-sm font-bold text-brand-violet">{L("المجالات الأكاديمية", "Academic fields")}</p>
      <h1 className="mt-4 max-w-3xl font-display text-4xl leading-tight md:text-6xl">{L("اختر مجالك، ثم تخصصك", "Choose your field, then your specialization")}</h1>
      <p className="mt-5 max-w-2xl text-lg leading-8 text-muted-foreground">{L("إن لم تجد تخصصك، اختر «تخصص آخر» في نموذج الطلب.", "If your specialization isn’t listed, choose “Other specialization” in the request form.")}</p>
    </div></section>
    <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8">
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{fields.map((f) => <FieldCard key={f.slug} field={f} />)}</div>
      <div className="mt-12 text-center"><Button asChild size="lg"><Link to="/request">{L("اطلب خدمة", "Request a Service")}</Link></Button></div>
    </section>
  </>;
}
