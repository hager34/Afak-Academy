import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { LoaderCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useLanguage } from "@/components/afak/language";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [
    { title: "تسجيل الدخول | أكاديمية آفاق" },
    { name: "description", content: "سجّل الدخول أو أنشئ حساباً لمتابعة طلباتك لدى أكاديمية آفاق." },
    { property: "og:title", content: "تسجيل الدخول — أكاديمية آفاق" },
    { property: "og:description", content: "حساب اختياري لمتابعة طلبات الخدمة." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function AuthPage() {
  const { isArabic } = useLanguage();
  const L = (a: string, e: string) => (isArabic ? a : e);
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: "/account", replace: true }); });
    const { data } = supabase.auth.onAuthStateChange((e, s) => { if (e === "SIGNED_IN" && s) navigate({ to: "/account", replace: true }); });
    return () => data.subscription.unsubscribe();
  }, [navigate]);

  async function submit(ev: FormEvent) {
    ev.preventDefault();
    setBusy(true);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) toast.error(L("البريد أو كلمة المرور غير صحيحة، أو لم يتم تأكيد البريد بعد.", "Wrong email or password, or email not confirmed yet."));
      } else if (mode === "signup") {
        if (password.length < 8) { toast.error(L("كلمة المرور 8 أحرف على الأقل.", "Password must be at least 8 characters.")); return; }
        const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin + "/account", data: { full_name: name.trim() } } });
        if (error) toast.error(error.message); else setSent(L("أرسلنا رابط تأكيد إلى بريدك. افتحه لتفعيل حسابك.", "We sent a confirmation link to your email. Open it to activate your account."));
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin + "/reset-password" });
        if (error) toast.error(error.message); else setSent(L("إذا كان البريد مسجلاً فستصلك رسالة لإعادة تعيين كلمة المرور.", "If this email is registered, you'll receive a reset link."));
      }
    } finally { setBusy(false); }
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/auth" });
    if (r.error) toast.error(L("تعذّر تسجيل الدخول عبر Google.", "Google sign-in failed."));
  }

  const title = mode === "signin" ? L("تسجيل الدخول", "Sign in") : mode === "signup" ? L("إنشاء حساب", "Create account") : L("نسيت كلمة المرور", "Forgot password");

  return (
    <section className="mx-auto max-w-md px-5 py-16">
      <h1 className="font-display text-4xl">{title}</h1>
      <p className="mt-3 text-sm leading-6 text-muted-foreground">{L("الحساب اختياري — يمكنك إرسال طلب دون تسجيل. الحساب يتيح لك متابعة طلباتك وحفظ بياناتك.", "An account is optional — you can send a request without one. It lets you follow your requests and save your details.")}</p>
      {sent ? (
        <div className="mt-8 border border-border bg-muted p-5 text-sm leading-6" role="status">{sent}</div>
      ) : (
        <>
          {mode !== "forgot" && (
            <>
              <Button type="button" variant="outline" className="mt-8 w-full" onClick={google}>{L("المتابعة باستخدام Google", "Continue with Google")}</Button>
              <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />{L("أو", "or")}<span className="h-px flex-1 bg-border" /></div>
            </>
          )}
          <form onSubmit={submit} className={mode === "forgot" ? "mt-8 grid gap-4" : "grid gap-4"}>
            {mode === "signup" && <div className="grid gap-2"><Label htmlFor="au-name">{L("الاسم الكامل", "Full name")}</Label><Input id="au-name" required maxLength={120} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></div>}
            <div className="grid gap-2"><Label htmlFor="au-email">{L("البريد الإلكتروني", "Email")}</Label><Input id="au-email" type="email" required maxLength={255} autoComplete="email" dir="ltr" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
            {mode !== "forgot" && <div className="grid gap-2"><Label htmlFor="au-pass">{L("كلمة المرور", "Password")}</Label><Input id="au-pass" type="password" required minLength={mode === "signup" ? 8 : 1} autoComplete={mode === "signup" ? "new-password" : "current-password"} dir="ltr" value={password} onChange={(e) => setPassword(e.target.value)} /></div>}
            <Button type="submit" disabled={busy}>{busy && <LoaderCircle className="animate-spin" />}{mode === "signin" ? L("دخول", "Sign in") : mode === "signup" ? L("إنشاء الحساب", "Create account") : L("إرسال الرابط", "Send link")}</Button>
          </form>
        </>
      )}
      <div className="mt-6 grid gap-2 text-sm">
        {mode !== "signin" && <button type="button" className="text-start font-semibold text-primary underline" onClick={() => { setMode("signin"); setSent(null); }}>{L("لديك حساب؟ سجّل الدخول", "Have an account? Sign in")}</button>}
        {mode !== "signup" && <button type="button" className="text-start font-semibold text-primary underline" onClick={() => { setMode("signup"); setSent(null); }}>{L("ليس لديك حساب؟ أنشئ حساباً", "No account? Create one")}</button>}
        {mode === "signin" && <button type="button" className="text-start text-muted-foreground underline" onClick={() => setMode("forgot")}>{L("نسيت كلمة المرور؟", "Forgot password?")}</button>}
        <Link to="/request" className="text-muted-foreground underline">{L("أرسل طلباً دون حساب", "Send a request without an account")}</Link>
      </div>
    </section>
  );
}
