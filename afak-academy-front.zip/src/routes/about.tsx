import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2, Eye, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/afak/shared";
import { useLanguage } from "@/components/afak/language";
import { seo } from "@/lib/seo";

export const Route = createFileRoute("/about")({
  head: () => seo("/about", "من نحن | أكاديمية آفاق", "أكاديمية آفاق منصة دعم أكاديمي متعددة التخصصات تجعل المواد الجامعية المعقدة أسهل فهماً وتنظيماً وعرضاً."),
  component: About,
});

const values: [string, string][] = [["الفهم قبل الحفظ", "Understanding before memorization"], ["عمل أصيل ومسؤول", "Original and responsible work"], ["تواصل واضح", "Clear communication"], ["الجودة والتنظيم", "Quality and organization"], ["احترام خصوصية الطالب", "Respect for student privacy"], ["التعلم المستمر", "Continuous learning"], ["النزاهة الأكاديمية", "Academic integrity"]];

function About() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  return <>
    <section className="bg-brand-paper py-24"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <p className="text-sm font-bold text-brand-violet">{L("من نحن", "About us")}</p>
      <h1 className="mt-4 max-w-4xl font-display text-4xl leading-tight md:text-6xl">{L("نجعل المواد الجامعية أسهل فهماً وتنظيماً وعرضاً.", "Making university subjects easier to understand, organize, and present.")}</h1>
      <p className="mt-6 max-w-3xl text-lg leading-8 text-muted-foreground">{L("أكاديمية آفاق منصة دعم تعليمي متعددة التخصصات لطلاب الجامعات، تهدف إلى تبسيط المقررات المعقدة والعمل الأكاديمي من خلال شرح مخصص ودعم في المشروعات والعروض التقديمية.", "Afak Academy is a multidisciplinary educational support platform for university students, aiming to make complex subjects and academic work easier through personalized explanation and support with projects and presentations.")}</p>
    </div></section>
    <section className="mx-auto grid max-w-7xl gap-5 px-5 py-20 md:grid-cols-2 lg:px-8">
      {[{ i: Target, t: L("رسالتنا", "Our mission"), d: L("تقديم دعم أكاديمي متاح ومخصص وعالي الجودة عبر مختلف المجالات الجامعية.", "To provide accessible, customized, and high-quality academic support across different university fields.") }, { i: Eye, t: L("رؤيتنا", "Our vision"), d: L("أن نصبح منصة تعلم ودعم أكاديمي موثوقة ومتعددة التخصصات لطلاب الجامعات.", "To become a trusted multidisciplinary learning and academic-support platform for university students.") }].map((x) => <article key={x.t} className="bg-brand-navy p-8 text-brand-paper md:p-12"><x.i className="size-8 text-brand-gold" /><h2 className="mt-8 font-display text-3xl">{x.t}</h2><p className="mt-4 text-lg leading-8 text-brand-paper/75">{x.d}</p></article>)}
    </section>
    <section className="bg-muted py-24"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <SectionHeading eyebrow={L("قيمنا", "Our values")} title={L("ما يوجّه عملنا مع كل طالب", "What guides our work with every student")} />
      <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{values.map(([a, e]) => <li key={e} className="flex items-center gap-3 border border-border bg-background p-5 font-semibold"><CheckCircle2 className="size-5 shrink-0 text-brand-violet" />{L(a, e)}</li>)}</ul>
    </div></section>
    <section className="mx-auto max-w-7xl px-5 py-20 text-center lg:px-8">
      <h2 className="font-display text-3xl">{L("جاهز للبدء؟", "Ready to start?")}</h2>
      <div className="mt-6 flex flex-wrap justify-center gap-3"><Button asChild size="lg"><Link to="/request">{L("اطلب خدمة", "Request a Service")}</Link></Button><Button asChild size="lg" variant="outline"><Link to="/services">{L("استكشف الخدمات", "Explore services")}</Link></Button></div>
    </section>
  </>;
}
