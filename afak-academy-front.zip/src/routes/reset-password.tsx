import { useState, type FormEvent } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/components/afak/language";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [
    { title: "تعيين كلمة مرور جديدة | أكاديمية آفاق" },
    { name: "description", content: "اختر كلمة مرور جديدة لحسابك في أكاديمية آفاق." },
    { property: "og:title", content: "تعيين كلمة مرور جديدة — أكاديمية آفاق" },
    { property: "og:description", content: "إعادة تعيين كلمة المرور." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
    { name: "robots", content: "noindex" },
  ] }),
  component: Page,
});

function Page() {
  const { isArabic } = useLanguage();
  const L = (a: string, e: string) => (isArabic ? a : e);
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(ev: FormEvent) {
    ev.preventDefault();
    if (password.length < 8) { toast.error(L("كلمة المرور 8 أحرف على الأقل.", "Password must be at least 8 characters.")); return; }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) { toast.error(L("انتهت صلاحية الرابط أو أنه غير صالح. اطلب رابطاً جديداً.", "The link is invalid or expired. Request a new one.")); return; }
    toast.success(L("تم تحديث كلمة المرور.", "Password updated."));
    navigate({ to: "/account", replace: true });
  }
  return (
    <section className="mx-auto max-w-md px-5 py-16">
      <h1 className="font-display text-4xl">{L("كلمة مرور جديدة", "New password")}</h1>
      <form onSubmit={submit} className="mt-8 grid gap-4">
        <div className="grid gap-2"><Label htmlFor="rp-pass">{L("كلمة المرور الجديدة", "New password")}</Label><Input id="rp-pass" type="password" required minLength={8} autoComplete="new-password" dir="ltr" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <Button type="submit" disabled={busy}>{L("حفظ", "Save")}</Button>
      </form>
    </section>
  );
}
