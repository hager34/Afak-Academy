import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpLeft, CheckCircle2, MessageSquareQuote } from "lucide-react";
import heroImage from "@/assets/afak-learning-studio.jpg";
import logo from "@/assets/afak-logo.png";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/afak/shared";
import { FieldCard, ServiceCard } from "@/components/afak/cards";
import { useLanguage } from "@/components/afak/language";
import { benefits, exampleRequests, fields, howItWorks, services } from "@/content/services";
import { t } from "@/content/site";

const img = "https://afakacademy.online/images/afak-social-share.jpg";
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "أكاديمية آفاق | دعم أكاديمي مصمم وفق احتياجاتك الجامعية" },
      { name: "description", content: "شرح المقررات الجامعية ودعم المشروعات والعروض التقديمية في الهندسة والطب والحاسب والأعمال والعلوم." },
      { property: "og:title", content: "أكاديمية آفاق | دعم أكاديمي للطلاب الجامعيين" },
      { property: "og:description", content: "اختر مجالك واطلب الدعم في المقررات أو المشروعات أو العروض التقديمية." },
      { property: "og:type", content: "website" }, { property: "og:url", content: "https://afakacademy.online/" },
      { property: "og:image", content: img }, { name: "twitter:card", content: "summary_large_image" }, { name: "twitter:image", content: img },
    ],
    links: [{ rel: "canonical", href: "https://afakacademy.online/" }],
    scripts: [{ type: "application/ld+json", children: JSON.stringify({ "@context": "https://schema.org", "@type": "EducationalOrganization", name: "Afak Academy", url: "https://afakacademy.online", description: "Multidisciplinary educational support platform for university students." }) }],
  }),
  component: HomePage,
});

function HomePage() {
  const { lang, isArabic } = useLanguage();
  const L = (ar: string, en: string) => (isArabic ? ar : en);
  return <>
    <section className="relative overflow-hidden border-b border-border bg-background">
      <div className="grid min-h-[650px] lg:grid-cols-2">
        <div className="relative order-2 min-h-80 overflow-hidden bg-brand-navy lg:order-1 lg:min-h-full">
          <img src={heroImage} width={1600} height={1100} alt={L("طالبة جامعية تدرس عبر الإنترنت", "A university student studying online")} className="absolute inset-0 h-full w-full object-cover object-center opacity-80" />
          <div className="absolute inset-0 bg-brand-navy/35" />
          <div className="absolute inset-x-0 bottom-0 border-t border-brand-paper/20 bg-brand-navy/85 px-6 py-5 text-brand-paper backdrop-blur-sm md:px-10">
            <p className="text-sm font-semibold">{L("شرح المقررات · دعم المشروعات · العروض التقديمية", "Course explanations · Project support · Presentations")}</p>
          </div>
        </div>
        <div className="order-1 flex items-center bg-brand-paper/40 px-5 py-14 lg:order-2 lg:px-16 lg:py-20">
          <div className="mx-auto max-w-2xl lg:mx-0">
            <div className="flex items-center gap-4">
              <span className="h-12 w-1.5 bg-brand-gold" />
              <p className="text-sm font-bold text-brand-violet">{L("لطلاب الجامعات في مجالات متعددة", "For university students across multiple fields")}</p>
            </div>
            <h1 className="mt-7 font-display text-4xl leading-[1.25] text-brand-navy md:text-6xl">{L("دعم أكاديمي مصمم وفق احتياجاتك الجامعية", "Academic Support Designed Around Your University Needs")}</h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-muted-foreground">{L("اختر مجالك واطلب الدعم في شرح المقررات الجامعية أو المشروعات أو العروض التقديمية.", "Choose your field and request help with university courses, academic projects, or professional presentations.")}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg"><Link to="/request">{L("اطلب خدمة", "Request a Service")}<ArrowUpLeft className="ltr:rotate-90" /></Link></Button>
              <Button asChild size="lg" variant="outline"><Link to="/fields">{L("استكشف المجالات الأكاديمية", "Explore Academic Fields")}</Link></Button>
            </div>
            <p className="mt-7 flex items-center gap-2 text-sm font-medium text-brand-violet"><CheckCircle2 className="size-4 text-brand-gold" />{L("كل طلب يُراجع ويحصل على خطة مخصصة.", "Every request is reviewed and receives a customized plan.")}</p>
          </div>
        </div>
      </div>
      <div className="absolute start-1/2 top-1/2 hidden size-36 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border-8 border-background bg-background p-3 shadow-xl lg:flex rtl:translate-x-1/2">
        <img src={logo} width={913} height={549} alt="" className="w-full" aria-hidden="true" />
      </div>
    </section>

    <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
      <SectionHeading eyebrow={L("خدماتنا", "Our services")} title={L("ثلاث خدمات رئيسية، مصممة حول احتياجك", "Three core services, shaped around your needs")} />
      <div className="mt-10 grid gap-5 lg:grid-cols-3">{services.map((s, i) => <ServiceCard key={s.slug} service={s} index={i} />)}</div>
    </section>

    <section className="border-y border-border bg-brand-paper py-24"><div className="mx-auto max-w-7xl px-5 lg:px-8">
      <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
        <SectionHeading eyebrow={L("المجالات الأكاديمية", "Academic fields")} title={L("دعم عبر تخصصات جامعية متعددة", "Support across many university specializations")} />
        <Button asChild variant="outline"><Link to="/fields">{L("عرض كل المجالات", "View All Fields")}</Link></Button>
      </div>
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">{fields.map((f) => <FieldCard key={f.slug} field={f} />)}</div>
    </div></section>

    <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
      <SectionHeading centered eyebrow={L("كيف نعمل", "How it works")} title={L("خمس خطوات واضحة", "Five clear steps")} />
      <ol className="mt-14 grid gap-8 md:grid-cols-5">{howItWorks.map((s, i) => <li key={s.title.en} className="text-center"><span className="mx-auto grid size-12 place-items-center rounded-full bg-brand-navy font-display text-lg text-brand-gold">{isArabic ? (i + 1).toLocaleString("ar-EG") : i + 1}</span><h3 className="mt-4 font-display text-lg">{t(s.title, lang)}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">{t(s.text, lang)}</p></li>)}</ol>
      <div className="mt-10 text-center"><Button asChild variant="outline"><Link to="/how-it-works">{L("تفاصيل آلية العمل", "How it works in detail")}</Link></Button></div>
    </section>

    <section className="border-y border-border bg-muted py-24"><div className="mx-auto grid max-w-7xl gap-14 px-5 lg:grid-cols-2 lg:px-8">
      <div>
        <SectionHeading eyebrow={L("لماذا آفاق؟", "Why Afak Academy")} title={L("دعم منظم يركّز على الفهم", "Organized support focused on understanding")} />
        <ul className="mt-8 grid gap-4">{benefits.map((b) => <li key={b.en} className="flex items-center gap-3 border-b border-border pb-4 font-semibold"><CheckCircle2 className="size-5 shrink-0 text-brand-violet" />{t(b, lang)}</li>)}</ul>
      </div>
      <div>
        <SectionHeading eyebrow={L("أمثلة", "Examples")} title={L("طلبات توضيحية من الطلاب", "Example student requests")} description={L("أمثلة توضيحية لطريقة استخدام المنصة، وليست طلبات حقيقية.", "Illustrative examples of how students might use the platform — not real requests.")} />
        <div className="mt-8 grid gap-3">{exampleRequests.map((x) => <Link key={x.text.en} to="/request" search={{ service: x.service, field: x.field }} className="flex gap-3 border border-border bg-background p-4 transition-colors hover:border-brand-violet"><MessageSquareQuote className="size-5 shrink-0 text-brand-gold" /><span><span className="text-[11px] font-bold text-brand-violet">{L("مثال", "Example")}</span><span className="block">“{t(x.text, lang)}”</span></span></Link>)}</div>
      </div>
    </div></section>

    <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
      <div className="border-s-8 border-brand-gold bg-brand-navy p-10 text-center text-brand-paper md:p-16">
        <h2 className="mx-auto max-w-3xl font-display text-3xl leading-snug md:text-5xl">{L("أخبرنا بما تحتاجه، وسنساعدك على اختيار الخدمة المناسبة.", "Tell us what you need, and we will help you choose the right service.")}</h2>
        <Button asChild size="lg" variant="gold" className="mt-8"><Link to="/request">{L("ابدأ طلبك", "Start Your Request")}</Link></Button>
      </div>
    </section>
  </>;
}
