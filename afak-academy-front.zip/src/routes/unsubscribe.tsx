import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { LoaderCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/afak/language";
import { StatusPanel } from "@/components/afak/status-panel";
import { api } from "@/services/api";
import { seo } from "@/lib/seo";

const tok = (v: unknown) => (typeof v === "string" && v.length <= 100 ? v : undefined);
export const Route = createFileRoute("/unsubscribe")({
  validateSearch: (s: Record<string, unknown>): { token?: string | undefined } => ({ token: tok(s["token"]) }),
  head: () => seo("/unsubscribe", "إلغاء الاشتراك | أكاديمية آفاق", "إلغاء الاشتراك من رسائل أكاديمية آفاق البريدية.", { noindex: true }),
  component: Page,
});

type S = "idle" | "busy" | "unsubscribed" | "already_unsubscribed" | "invalid" | "network";

function Page() {
  const { isArabic } = useLanguage(); const L = (a: string, e: string) => (isArabic ? a : e);
  const { token } = Route.useSearch(); const [s, setS] = useState<S>("idle");
  const home = <Button asChild variant="outline"><Link to="/">{L("العودة للرئيسية", "Back to home")}</Link></Button>;
  if (!token) return <StatusPanel tone="info" title={L("إلغاء الاشتراك", "Unsubscribe")}><p>{L("استخدم رابط «إلغاء الاشتراك» الموجود أسفل أي رسالة من آفاق.", "Use the “Unsubscribe” link at the bottom of any Afak email.")}</p>{home}</StatusPanel>;
  if (s === "unsubscribed" || s === "already_unsubscribed") return <StatusPanel tone="success" title={L("تم إلغاء اشتراكك", "You have been unsubscribed")}><p>{L("لن تصلك رسائل النشرة بعد الآن. قد تصلك رسائل تخص طلب خدمة قدمته فقط عند الضرورة.", "You will no longer receive newsletter emails. You may still receive messages about a service request you submitted, only when necessary.")}</p>{home}</StatusPanel>;
  if (s === "invalid") return <StatusPanel tone="warning" title={L("رابط غير صالح", "Invalid link")}><p>{L("لم نتمكن من التعرف على هذا الرابط.", "We couldn't recognise this link.")}</p>{home}</StatusPanel>;
  async function go() {
    setS("busy");
    try { const r = await api.unsubscribe(token!); setS(r.status); } catch { setS("network"); }
  }
  return (
    <StatusPanel tone="info" title={L("إلغاء الاشتراك من النشرة", "Unsubscribe from the newsletter")}>
      <p>{L("هل تريد إيقاف جميع رسائل النشرة التعليمية والإعلانية؟", "Do you want to stop all educational and promotional newsletter emails?")}</p>
      {s === "network" && <p role="alert" className="text-destructive">{L("خطأ في الشبكة، حاول مجدداً.", "Network error, please try again.")}</p>}
      <div className="flex flex-wrap justify-center gap-3">
        <Button onClick={go} disabled={s === "busy"}>{s === "busy" && <LoaderCircle className="animate-spin" />}{L("تأكيد إلغاء الاشتراك", "Confirm unsubscribe")}</Button>
        <Button asChild variant="outline"><Link to="/email-preferences" search={{ token }}>{L("تعديل التفضيلات بدلاً من ذلك", "Change preferences instead")}</Link></Button>
      </div>
    </StatusPanel>
  );
}
