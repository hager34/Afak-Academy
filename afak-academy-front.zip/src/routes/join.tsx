import { createFileRoute, redirect } from "@tanstack/react-router";

// Obsolete URL: enrollment interest was replaced by the service request form.
export const Route = createFileRoute("/join")({
  beforeLoad: () => { throw redirect({ to: "/request", statusCode: 301 }); },
});
