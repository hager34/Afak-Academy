import { Atom, BookOpen, BriefcaseBusiness, Cpu, FolderKanban, HardHat, HeartPulse, Presentation } from "lucide-react";
import type { Field, Service } from "@/content/services";

const fieldIcons = { engineering: HardHat, medicine: HeartPulse, computing: Cpu, business: BriefcaseBusiness, sciences: Atom } as const;
const serviceIcons = { courses: BookOpen, projects: FolderKanban, presentations: Presentation } as const;

export function FieldIcon({ icon, className }: { icon: Field["icon"]; className?: string }) { const I = fieldIcons[icon]; return <I className={className} aria-hidden="true" />; }
export function ServiceIcon({ icon, className }: { icon: Service["icon"]; className?: string }) { const I = serviceIcons[icon]; return <I className={className} aria-hidden="true" />; }
