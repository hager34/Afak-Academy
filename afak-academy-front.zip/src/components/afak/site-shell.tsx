import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { ArrowUpLeft, Languages, Mail, Menu, Settings2, UserRound, X } from "lucide-react";
import { useSession } from "./auth";
import { toast } from "sonner";
import { Brand } from "./brand";
import { useLanguage } from "./language";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/services/api";
import { newsletterSchema } from "@/lib/validation";
import { contact } from "@/content/site";

const nav = [
  { to: "/", ar: "الرئيسية", en: "Home" },
  { to: "/services", ar: "الخدمات", en: "Services" },
  { to: "/fields", ar: "المجالات الأكاديمية", en: "Academic Fields" },
  { to: "/how-it-works", ar: "كيف نعمل", en: "How It Works" },
  { to: "/about", ar: "من نحن", en: "About Us" },
  { to: "/contact", ar: "تواصل معنا", en: "Contact" },
] as const;

export function SiteShell({ children }: { children: ReactNode }) {
  const { lang, setLang, isArabic } = useLanguage();
  const [menuOpen, setMenuOpen] = useState(false);
  const [cookiesOpen, setCookiesOpen] = useState(false);
  const { user } = useSession();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  useEffect(() => setMenuOpen(false), [pathname]);
  useEffect(() => { if (!window.localStorage.getItem("afak-cookie-choice")) setCookiesOpen(true); }, []);
  const label = (ar: string, en: string) => isArabic ? ar : en;
  const chooseCookies = (value: "all" | "essential") => { window.localStorage.setItem("afak-cookie-choice", value); setCookiesOpen(false); };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <a href="#main-content" className="sr-only z-[100] bg-primary px-4 py-2 text-primary-foreground focus:not-sr-only focus:fixed focus:start-4 focus:top-4">{label("انتقل إلى المحتوى", "Skip to content")}</a>
      <div className="border-b border-brand-gold/30 bg-brand-navy px-4 py-2 text-center text-xs font-semibold text-brand-paper">
        {label("دعم أكاديمي مخصص عبر تخصصات جامعية متعددة", "Customized academic support across multiple university fields")}
      </div>
      <header className="sticky top-0 z-50 border-b border-border/80 bg-background/95 backdrop-blur-xl">
        <div className="mx-auto flex h-24 max-w-7xl items-center justify-between gap-4 px-5 lg:px-8">
          <Brand />
          <nav className="hidden items-center gap-5 xl:gap-7 lg:flex" aria-label={label("التنقل الرئيسي", "Main navigation")}>
            {nav.map((item) => <Link key={item.to} to={item.to} className="border-b-2 border-transparent py-2 text-sm font-semibold text-muted-foreground transition-colors hover:border-brand-gold hover:text-primary" activeProps={{ className: "border-brand-gold text-primary" }} activeOptions={{ exact: item.to === "/" }}>{item[lang]}</Link>)}
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setLang(isArabic ? "en" : "ar")} aria-label={label("Switch to English", "التبديل إلى العربية")}><Languages /> {isArabic ? "EN" : "العربية"}</Button>
            <Button asChild variant="ghost" size="sm"><Link to={user ? "/account" : "/auth"} aria-label={user ? label("حسابي", "My account") : label("تسجيل الدخول", "Sign in")}><UserRound /> <span className="hidden md:inline">{user ? label("حسابي", "My account") : label("دخول", "Sign in")}</span></Link></Button>
            <Button asChild className="hidden sm:inline-flex"><Link to="/request">{label("اطلب خدمة", "Request a Service")} <ArrowUpLeft className="rtl:-scale-x-100" /></Link></Button>
            <Button variant="outline" size="icon" className="lg:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-label={label("فتح القائمة", "Open menu")}>{menuOpen ? <X /> : <Menu />}</Button>
          </div>
        </div>
        {menuOpen && <nav className="border-t border-border bg-background px-5 py-5 lg:hidden" aria-label={label("قائمة الهاتف", "Mobile navigation")}><div className="mx-auto grid max-w-7xl gap-1">{nav.map((item) => <Link key={item.to} to={item.to} className="rounded-md px-4 py-3 font-semibold hover:bg-muted">{item[lang]}</Link>)}<Button asChild className="mt-3"><Link to="/request">{label("اطلب خدمة", "Request a Service")}</Link></Button></div></nav>}
      </header>
      <main id="main-content">{children}</main>
      <Footer />
      {cookiesOpen && <div className="fixed inset-x-4 bottom-4 z-50 mx-auto max-w-3xl border border-border bg-background p-5 shadow-2xl" role="dialog" aria-label={label("تفضيلات ملفات الارتباط", "Cookie preferences")}><div className="flex flex-col gap-4 sm:flex-row sm:items-center"><Settings2 className="size-6 shrink-0 text-brand-violet" /><p className="flex-1 text-sm leading-6 text-muted-foreground">{label("نستخدم ملفات ضرورية لعمل الموقع، ويمكنك اختيار السماح بملفات القياس عند إضافتها مستقبلاً.", "We use essential cookies for site function. You can choose whether to allow measurement cookies if added later.")} <Link to="/cookies" className="font-semibold text-primary underline">{label("اقرأ السياسة", "Read policy")}</Link></p><div className="flex gap-2"><Button variant="outline" onClick={() => chooseCookies("essential")}>{label("الضرورية فقط", "Essential only")}</Button><Button onClick={() => chooseCookies("all")}>{label("السماح بالكل", "Allow all")}</Button></div></div></div>}
    </div>
  );
}

function Footer() {
  const { isArabic } = useLanguage();
  const [email, setEmail] = useState("");
  const [pending, setPending] = useState(false);
  const label = (ar: string, en: string) => isArabic ? ar : en;
  const navigate = useNavigate();
  async function submit(event: FormEvent) {
    event.preventDefault(); const parsed = newsletterSchema.safeParse({ email });
    if (!parsed.success) { toast.error(label("أدخل بريداً إلكترونياً صحيحاً", "Enter a valid email")); return; }
    setPending(true);
    try {
      const r = await api.subscribeNewsletter({ email: parsed.data.email, language: isArabic ? "ar" : "en" });
      if (!r.ok) { toast.error(label("محاولات كثيرة، حاول لاحقاً.", "Too many attempts, try later.")); return; }
      if (r.devConfirmUrl) sessionStorage.setItem("afak-dev-confirm", r.devConfirmUrl);
      setEmail(""); navigate({ to: "/check-your-email" });
    } catch { toast.error(label("تعذّر الاشتراك، حاول مجدداً.", "Could not subscribe, please try again.")); } finally { setPending(false); }
  }
  return <footer className="border-t-4 border-brand-gold bg-brand-navy text-brand-paper"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-[1.3fr_1fr_1fr] lg:px-8"><div><Brand footer /><p className="mt-5 max-w-sm text-sm leading-7 text-brand-paper/70">{label("منصة دعم أكاديمي متعددة التخصصات لطلاب الجامعات: شرح المقررات، والمشروعات، والعروض التقديمية.", "A multidisciplinary academic support platform for university students: courses, projects, and presentations.")}</p><p className="mt-4 text-xs text-brand-paper/50">{label("جميع التفاصيل والأرقام المعروضة حالياً نموذجية وقابلة للتعديل.", "All displayed details and figures are currently sample and editable.")}</p></div><div><h2 className="font-display text-lg">{label("روابط مهمة", "Explore")}</h2><div className="mt-4 grid gap-3 text-sm text-brand-paper/70 [&_a]:transition-colors [&_a:hover]:text-brand-gold"><Link to="/services">{label("الخدمات", "Services")}</Link><Link to="/fields">{label("المجالات الأكاديمية", "Academic fields")}</Link><Link to="/request">{label("اطلب خدمة", "Request a service")}</Link><Link to="/about">{label("عن آفاق", "About Afak")}</Link><Link to="/contact">{label("تواصل معنا", "Contact")}</Link><Link to="/privacy">{label("الخصوصية", "Privacy")}</Link><Link to="/terms">{label("الشروط", "Terms")}</Link><Link to="/email-preferences">{label("تفضيلات البريد", "Email preferences")}</Link></div></div><div><h2 className="font-display text-lg">{label("رسالة مفيدة، لا ضوضاء", "Useful notes, no noise")}</h2><p className="mt-3 text-sm leading-6 text-brand-paper/70">{label("تحديثات الخدمات وموارد تعلم منتقاة. نطلب تأكيد الاشتراك عبر البريد، ويمكنك الإلغاء في أي وقت.", "Service updates and selected learning resources. We ask you to confirm by email; unsubscribe any time.")}</p><form onSubmit={submit} className="mt-4 flex gap-2"><label className="sr-only" htmlFor="footer-email">{label("البريد الإلكتروني", "Email")}</label><Input id="footer-email" value={email} onChange={(e) => setEmail(e.target.value)} className="border-brand-paper/20 bg-brand-paper/10 text-brand-paper placeholder:text-brand-paper/50" placeholder="name@example.com" maxLength={255} /><Button type="submit" variant="gold" size="icon" disabled={pending} aria-label={label("اشترك", "Subscribe")}><Mail /></Button></form><p className="mt-4 text-sm text-brand-paper/70">{contact.email}<br /><span dir="ltr">{contact.phone}</span></p></div></div><div className="border-t border-brand-paper/10 px-5 py-5 text-center text-xs text-brand-paper/50">© 2026 Afak Academy · {label("المدفوعات غير متاحة عبر الموقع حالياً", "No payments are taken on this website")}</div></footer>;
}
