import { Link } from "@tanstack/react-router";
import { ArrowUpLeft, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "./language";
import { FieldIcon, ServiceIcon } from "./icons";
import { t } from "@/content/site";
import type { Field, Service } from "@/content/services";

const tone = ["bg-brand-navy text-brand-paper", "bg-background text-foreground", "bg-background text-foreground"];

export function ServiceCard({ service, index = 0 }: { service: Service; index?: number }) {
  const { lang, isArabic } = useLanguage();
  const dark = index === 0;
  return (
    <article className={`group flex h-full flex-col border border-border border-t-4 p-7 shadow-sm transition-[transform,box-shadow] duration-300 hover:-translate-y-1 hover:shadow-lg motion-reduce:transform-none ${dark ? "border-t-brand-gold" : "border-t-brand-violet"} ${tone[index % 3]}`}>
      <span className={`grid size-14 place-items-center rounded-md ${dark ? "bg-brand-paper/10 text-brand-gold" : "bg-brand-paper text-brand-violet"}`}><ServiceIcon icon={service.icon} className="size-6" /></span>
      <h3 className="mt-6 font-display text-2xl">{t(service.title, lang)}</h3>
      <p className={`mt-3 leading-7 ${dark ? "text-brand-paper/75" : "text-muted-foreground"}`}>{t(service.short, lang)}</p>
      <ul className="mt-6 grid gap-2 text-sm">
        {service.items.slice(0, 4).map((item) => <li key={item.en} className="flex gap-2"><Check className="mt-0.5 size-4 shrink-0 text-brand-gold" />{t(item, lang)}</li>)}
      </ul>
      <div className="mt-auto flex flex-wrap gap-3 pt-8">
        <Button asChild variant={dark ? "gold" : "default"}><Link to="/request" search={{ service: service.slug }}>{t(service.cta, lang)}</Link></Button>
        <Button asChild variant="link" className={dark ? "text-brand-paper" : ""}><Link to="/services/$serviceSlug" params={{ serviceSlug: service.slug }}>{isArabic ? "اعرف المزيد" : "Learn more"} <ArrowUpLeft className="ltr:rotate-90" /></Link></Button>
      </div>
    </article>
  );
}

export function FieldCard({ field }: { field: Field }) {
  const { lang, isArabic } = useLanguage();
  return (
    <Link to="/fields/$fieldSlug" params={{ fieldSlug: field.slug }} className="group flex h-full flex-col border border-border border-t-4 border-t-brand-violet bg-background p-6 shadow-sm transition-[transform,box-shadow] hover:-translate-y-1 hover:shadow-md focus-visible:border-brand-violet">
      <span className="grid size-12 place-items-center rounded-md bg-brand-paper text-brand-violet transition-colors group-hover:bg-brand-navy group-hover:text-brand-gold"><FieldIcon icon={field.icon} className="size-6" /></span>
      <h3 className="mt-5 font-display text-xl">{t(field.name, lang)}</h3>
      <p className="mt-2 text-sm leading-6 text-muted-foreground">{t(field.description, lang)}</p>
      <p className="mt-4 text-xs text-muted-foreground">{field.specializations.slice(0, 4).map((s) => t(s.name, lang)).join(" · ")}…</p>
      <span className="mt-auto pt-5 text-sm font-bold text-brand-violet">{isArabic ? `${field.specializations.length} تخصصاً ←` : `${field.specializations.length} specializations →`}</span>
    </Link>
  );
}
