import { useEffect, useMemo, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Link, useNavigate } from "@tanstack/react-router";
import { Info, LoaderCircle, Paperclip } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useLanguage } from "./language";
import { Field } from "./forms";
import { ServiceIcon } from "./icons";
import { api } from "@/services/api";
import { requestSteps, type ServiceRequestPayload } from "@/lib/validation";
import { fields, services } from "@/content/services";
import { t } from "@/content/site";

type State = Record<string, string | boolean>;
const selectCls = "h-12 w-full rounded-md border border-input bg-background px-3 text-sm";

export function RequestForm({ initial }: { initial: { service?: string | undefined; field?: string | undefined; specialization?: string | undefined } }) {
  const { lang, isArabic } = useLanguage();
  const L = (a: string, e: string) => (isArabic ? a : e);
  const validService = services.some((s) => s.slug === initial.service) ? initial.service! : "";
  const validField = fields.some((f) => f.slug === initial.field) ? initial.field! : "";
  const validSpec = validField && fields.find((f) => f.slug === validField)!.specializations.some((s) => s.slug === initial.specialization) ? initial.specialization! : "";
  const [data, setData] = useState<State>({ service: validService, field: validField, specialization: validSpec, language: "ar", delivery: "email", consent: false, newsletter: false, website: "" });
  const navigate = useNavigate();
  const firstStep = validService ? (validField ? (validSpec ? 3 : 2) : 1) : 0;
  const [step, setStep] = useState(firstStep);
  const [errors, setErrors] = useState<Record<string, boolean>>({});
  const [busy, setBusy] = useState(false);
  // Signed-in students: prefill contact details from their saved profile (only empty fields).
  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!session) return;
      const { data: p } = await supabase.from("profiles").select("full_name,phone,whatsapp,country,time_zone").eq("id", session.user.id).maybeSingle();
      const fill: Record<string, string> = { email: session.user.email ?? "", name: p?.full_name ?? "", phone: p?.phone ?? "", whatsapp: p?.whatsapp ?? "", country: p?.country ?? "", timezone: p?.time_zone ?? "" };
      setData((d) => { const n = { ...d }; for (const [k, v] of Object.entries(fill)) if (v && !n[k]) n[k] = v; return n; });
    });
  }, []);

  const set = (k: string, v: string | boolean) => setData((d) => ({ ...d, [k]: v, ...(k === "field" ? { specialization: "" } : {}) }));
  const str = (k: string) => (typeof data[k] === "string" ? (data[k] as string) : "");
  const field = fields.find((f) => f.slug === data["field"]);

  const stepNames = [L("الخدمة", "Service"), L("المجال", "Field"), L("التخصص", "Specialization"), L("التفاصيل", "Details"), L("المتطلبات", "Requirements"), L("التواصل", "Contact"), L("المراجعة", "Review")];
  const levels: [string, string, string][] = [["school", "مدرسي", "School"], ["undergraduate", "جامعي", "Undergraduate"], ["postgraduate", "دراسات عليا", "Postgraduate"], ["professional", "مهني", "Professional"], ["other", "أخرى", "Other"]];
  const langs: [string, string, string][] = [["ar", "العربية", "Arabic"], ["en", "الإنجليزية", "English"], ["both", "العربية والإنجليزية", "Arabic and English"]];
  const contactMethods: [string, string, string][] = [["email", "البريد الإلكتروني", "Email"], ["whatsapp", "واتساب", "WhatsApp"], ["phone", "مكالمة هاتفية", "Phone call"]];
  const label = (list: [string, string, string][], v: string) => { const x = list.find((i) => i[0] === v); return x ? L(x[1], x[2]) : "—"; };

  function validate(i: number) {
    if (i > 5) return true;
    const r = requestSteps[i]!.safeParse(data);
    if (r.success) { setErrors({}); return true; }
    const e: Record<string, boolean> = {}; r.error.issues.forEach((x) => (e[String(x.path[0])] = true)); setErrors(e);
    toast.error(L("يرجى استكمال الحقول المطلوبة", "Please complete the required fields")); return false;
  }
  const next = () => { if (validate(step)) setStep((s) => Math.min(s + 1, 6)); };
  const back = () => { setErrors({}); setStep((s) => Math.max(s - 1, 0)); };

  async function submit() {
    for (let i = 0; i < 6; i++) if (!requestSteps[i]!.safeParse(data).success) { setStep(i); validate(i); return; }
    setBusy(true);
    try {
      const res = await api.submitServiceRequest({ ...(data as unknown as ServiceRequestPayload), uiLanguage: lang === "ar" ? "ar" : "en" });
      if (!res.ok) {
        toast.error(res.error === "RATE_LIMITED" ? L("تم إرسال طلبات كثيرة. حاول مرة أخرى لاحقاً.", "Too many requests. Please try again later.") : L("تعذّر إرسال الطلب. حاول مرة أخرى.", "We couldn't submit your request. Please try again."));
        return;
      }
      // Only non-private data is kept, for this tab session only; nothing goes in the URL.
      sessionStorage.setItem("afak-last-request", JSON.stringify({ n: res.requestNumber, e: res.emailEnabled, nl: res.newsletterPending, dev: res.devConfirmUrl }));
      navigate({ to: "/request/success" });
    } catch {
      toast.error(L("تعذّر الاتصال. تحقق من الشبكة وحاول مجدداً.", "Connection problem. Check your network and try again."));
    } finally { setBusy(false); }
  }

  const err = (k: string, ar = "هذا الحقل مطلوب أو غير صحيح", en = "This field is required or invalid") => (errors[k] ? L(ar, en) : undefined);
  const Choice = ({ name, value, children }: { name: string; value: string; children: ReactNode }) => (
    <button type="button" onClick={() => set(name, value)} aria-pressed={data[name] === value} className={`flex w-full items-center gap-3 border p-4 text-start transition-colors ${data[name] === value ? "border-brand-violet bg-brand-paper ring-2 ring-brand-violet/30" : "border-border hover:border-brand-violet/60"}`}>{children}</button>
  );

  const summary = useMemo(() => {
    const svc = services.find((s) => s.slug === data["service"]);
    const spec = data["specialization"] === "other" ? str("otherSpecialization") : field?.specializations.find((s) => s.slug === data["specialization"]);
    return [
      [L("الخدمة", "Service"), svc ? t(svc.title, lang) : "—"],
      [L("المجال", "Field"), field ? t(field.name, lang) : data["field"] === "other" ? L("أخرى", "Other") : "—"],
      [L("التخصص", "Specialization"), typeof spec === "string" ? spec || "—" : spec ? t(spec.name, lang) : data["specialization"] === "other" ? str("otherSpecialization") : "—"],
      [L("المؤسسة", "Institution"), str("institution") || "—"], [L("المستوى", "Level"), label(levels, str("level"))],
      [L("المقرر أو المادة", "Course or subject"), str("subject") || "—"], [L("العنوان", "Title"), str("title") || "—"], [L("لغة الشرح", "Language"), label(langs, str("language"))],
      [L("الوصف", "Description"), str("description") || "—"], [L("المهام", "Tasks"), str("tasks") || "—"], [L("الموعد النهائي", "Deadline"), str("deadline") || "—"],
      [L("طريقة التواصل المفضلة", "Preferred contact method"), label(contactMethods, str("delivery"))], [L("الميزانية", "Budget"), str("budget") || "—"],
      [L("الاسم", "Name"), str("name")], [L("البريد", "Email"), str("email")], [L("الهاتف", "Phone"), str("phone") || "—"], [L("واتساب", "WhatsApp"), str("whatsapp") || "—"],
      [L("الدولة", "Country"), str("country")], [L("المنطقة الزمنية", "Time zone"), str("timezone") || "—"],
      [L("النشرة البريدية", "Newsletter"), data["newsletter"] === true ? L("نعم — تتطلب تأكيداً عبر البريد", "Yes — requires email confirmation") : L("لا", "No")],
    ];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, lang]);

  return (
    <div>
      <ol className="mb-8 grid grid-cols-7 gap-1" aria-label={L("خطوات الطلب", "Request steps")}>
        {stepNames.map((n, i) => (
          <li key={n} aria-current={i === step ? "step" : undefined}>
            <span className={`block h-1.5 rounded-full ${i <= step ? "bg-brand-violet" : "bg-muted"}`} />
            <span className={`mt-2 hidden text-[11px] font-semibold sm:block ${i === step ? "text-brand-violet" : "text-muted-foreground"}`}>{n}</span>
          </li>
        ))}
      </ol>
      <p className="text-xs font-bold text-brand-violet">{L(`الخطوة ${i18n(step + 1, true)} من ٧`, `Step ${step + 1} of 7`)}</p>
      <h2 className="mt-2 font-display text-2xl md:text-3xl">{stepNames[step]}</h2>

      <div className="mt-6 grid gap-5">
        {step === 0 && <div className="grid gap-3" role="group" aria-label={stepNames[0]}>{services.map((s) => <Choice key={s.slug} name="service" value={s.slug}><ServiceIcon icon={s.icon} className="size-6 shrink-0 text-brand-violet" /><span><strong className="block">{t(s.title, lang)}</strong><span className="text-sm text-muted-foreground">{t(s.short, lang)}</span></span></Choice>)}{errors["service"] && <p role="alert" className="text-xs text-destructive">{L("اختر خدمة", "Choose a service")}</p>}</div>}

        {step === 1 && <div className="grid gap-3 sm:grid-cols-2" role="group" aria-label={stepNames[1]}>{fields.map((f) => <Choice key={f.slug} name="field" value={f.slug}><strong>{t(f.name, lang)}</strong></Choice>)}<Choice name="field" value="other"><strong>{L("مجال آخر", "Other")}</strong></Choice>{errors["field"] && <p role="alert" className="text-xs text-destructive sm:col-span-2">{L("اختر مجالاً", "Choose a field")}</p>}</div>}

        {step === 2 && <>
          <Field id="rq-spec" label={L("التخصص *", "Specialization *")} error={err("specialization")}>
            <select id="rq-spec" className={selectCls} value={str("specialization")} onChange={(e) => set("specialization", e.target.value)}>
              <option value="">{L("اختر التخصص", "Select a specialization")}</option>
              {field?.specializations.map((s) => <option key={s.slug} value={s.slug}>{t(s.name, lang)}</option>)}
              <option value="other">{L("تخصص آخر", "Other specialization")}</option>
            </select>
          </Field>
          {data["specialization"] === "other" && <Field id="rq-other" label={L("اكتب تخصصك *", "Your specialization *")} error={err("otherSpecialization")}><Input id="rq-other" maxLength={120} value={str("otherSpecialization")} onChange={(e) => set("otherSpecialization", e.target.value)} /></Field>}
        </>}

        {step === 3 && <>
          <Field id="rq-inst" label={L("الجامعة أو المؤسسة — اختياري", "University or institution — optional")}><Input id="rq-inst" maxLength={150} value={str("institution")} onChange={(e) => set("institution", e.target.value)} /></Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field id="rq-level" label={L("المستوى الأكاديمي *", "Academic level *")} error={err("level")}><select id="rq-level" className={selectCls} value={str("level")} onChange={(e) => set("level", e.target.value)}><option value="">{L("اختر", "Choose")}</option>{levels.map(([v, a, e]) => <option key={v} value={v}>{L(a, e)}</option>)}</select></Field>
            <Field id="rq-lang" label={L("لغة الشرح المفضلة *", "Preferred explanation language *")} error={err("language")}><select id="rq-lang" className={selectCls} value={str("language")} onChange={(e) => set("language", e.target.value)}>{langs.map(([v, a, e]) => <option key={v} value={v}>{L(a, e)}</option>)}</select></Field>
          </div>
          <Field id="rq-subject" label={L("اسم المقرر أو المادة", "Course or subject name")}><Input id="rq-subject" maxLength={150} value={str("subject")} onChange={(e) => set("subject", e.target.value)} /></Field>
          <Field id="rq-title" label={L("عنوان المشروع أو العرض", "Project or presentation title")}><Input id="rq-title" maxLength={200} value={str("title")} onChange={(e) => set("title", e.target.value)} /></Field>
        </>}

        {step === 4 && <>
          <Field id="rq-desc" label={L("وصف تفصيلي *", "Detailed description *")} error={err("description", "اكتب وصفاً لا يقل عن ٢٠ حرفاً", "Write at least 20 characters")}><Textarea id="rq-desc" className="min-h-36" maxLength={3000} value={str("description")} onChange={(e) => set("description", e.target.value)} /></Field>
          <Field id="rq-tasks" label={L("الدعم المطلوب", "Required support")}><Textarea id="rq-tasks" maxLength={1500} value={str("tasks")} onChange={(e) => set("tasks", e.target.value)} /></Field>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field id="rq-deadline" label={L("الموعد النهائي *", "Deadline *")} error={err("deadline", "اختر تاريخاً قادماً", "Choose an upcoming date")}><Input id="rq-deadline" type="date" min={new Date().toISOString().slice(0, 10)} value={str("deadline")} onChange={(e) => set("deadline", e.target.value)} /></Field>
            <Field id="rq-delivery" label={L("طريقة التواصل المفضلة *", "Preferred communication method *")} error={err("delivery")}><select id="rq-delivery" className={selectCls} value={str("delivery")} onChange={(e) => set("delivery", e.target.value)}>{contactMethods.map(([v, a, e]) => <option key={v} value={v}>{L(a, e)}</option>)}</select></Field>
          </div>
          <Field id="rq-budget" label={L("نطاق الميزانية — اختياري", "Budget range — optional")}><Input id="rq-budget" maxLength={60} placeholder={L("مثال: ١٠٠٠–٢٠٠٠ ج.م", "e.g. EGP 1,000–2,000")} value={str("budget")} onChange={(e) => set("budget", e.target.value)} /></Field>
          <p className="flex gap-3 border border-dashed border-border p-4 text-sm leading-6 text-muted-foreground"><Paperclip className="mt-0.5 size-5 shrink-0 text-brand-violet" />{L("يمكنك إرسال الملفات الداعمة للأكاديمية بعد مراجعة طلبك.", "You can share supporting files with the academy after your request is reviewed.")}</p>
        </>}

        {step === 5 && <>
          <div className="grid gap-5 sm:grid-cols-2">
            <Field id="rq-name" label={L("الاسم الكامل *", "Full name *")} error={err("name")}><Input id="rq-name" maxLength={100} autoComplete="name" value={str("name")} onChange={(e) => set("name", e.target.value)} /></Field>
            <Field id="rq-email" label={L("البريد الإلكتروني *", "Email address *")} error={err("email", "أدخل بريداً إلكترونياً صحيحاً", "Enter a valid email")}><Input id="rq-email" type="email" maxLength={255} autoComplete="email" value={str("email")} onChange={(e) => set("email", e.target.value)} /></Field>
            <Field id="rq-phone" label={L("رقم الهاتف — اختياري", "Phone number — optional")} error={err("phone")}><Input id="rq-phone" type="tel" dir="ltr" maxLength={30} autoComplete="tel" placeholder="+201550514323" value={str("phone")} onChange={(e) => set("phone", e.target.value)} /></Field>
            <Field id="rq-wa" label={L("رقم واتساب — اختياري", "WhatsApp number — optional")} error={err("whatsapp")}><Input id="rq-wa" type="tel" dir="ltr" maxLength={30} placeholder="+201550514323" value={str("whatsapp")} onChange={(e) => set("whatsapp", e.target.value)} /></Field>
            <Field id="rq-country" label={L("الدولة *", "Country *")} error={err("country")}><Input id="rq-country" maxLength={80} autoComplete="country-name" value={str("country")} onChange={(e) => set("country", e.target.value)} /></Field>
            <Field id="rq-tz" label={L("المنطقة الزمنية — اختياري", "Time zone — optional")} error={err("timezone")}><Input id="rq-tz" maxLength={80} placeholder="Africa/Cairo" value={str("timezone")} onChange={(e) => set("timezone", e.target.value)} /></Field>
          </div>
          <div className="absolute -start-[9999px]" aria-hidden="true"><label htmlFor="rq-website">Website</label><input id="rq-website" tabIndex={-1} autoComplete="off" value={str("website")} onChange={(e) => set("website", e.target.value)} /></div>
          <div>
            <div className="flex items-start gap-3"><Checkbox id="rq-consent" checked={data["consent"] === true} onCheckedChange={(v) => set("consent", v === true)} aria-invalid={!!errors["consent"]} aria-describedby={errors["consent"] ? "rq-consent-error" : undefined} />
              <label htmlFor="rq-consent" className="text-sm leading-6">{L("أوافق على أن تتواصل معي أكاديمية آفاق بخصوص طلب الخدمة، وأقر بأنني اطلعت على ", "I agree that Afak Academy may contact me regarding this service request, and I have read the ")}<Link to="/privacy" className="font-semibold text-primary underline">{L("سياسة الخصوصية", "Privacy Policy")}</Link>. *</label></div>
            {errors["consent"] && <p id="rq-consent-error" role="alert" className="ms-7 mt-1 text-xs text-destructive">{L("هذه الموافقة مطلوبة لإرسال الطلب", "This consent is required to submit the request")}</p>}
          </div>
          <div className="flex items-start gap-3"><Checkbox id="rq-newsletter" checked={data["newsletter"] === true} onCheckedChange={(v) => set("newsletter", v === true)} />
            <label htmlFor="rq-newsletter" className="text-sm leading-6">{L("أرغب أيضًا في استلام التحديثات التعليمية وإعلانات الأكاديمية والمعلومات المتعلقة بالخدمات عبر البريد الإلكتروني.", "I would also like to receive educational updates, academy announcements, and relevant service information by email.")} <span className="text-muted-foreground">{L("(اختياري — سنرسل رسالة تأكيد)", "(optional — we will ask you to confirm)")}</span></label></div>
        </>}

        {step === 6 && <>
          <dl className="divide-y divide-border border border-border">{summary.map(([k, v]) => <div key={k} className="grid gap-1 p-3 text-sm sm:grid-cols-[180px_1fr]"><dt className="font-bold">{k}</dt><dd className="whitespace-pre-wrap break-words text-muted-foreground">{v}</dd></div>)}</dl>
          <p className="flex gap-3 border border-brand-gold bg-brand-gold-soft/40 p-4 text-sm leading-6"><Info className="mt-0.5 size-5 shrink-0 text-brand-navy" />{L("إرسال الطلب لا يترتب عليه أي التزام بالدفع. سيراجع فريقنا طلبك ويتواصل معك قبل مناقشة أي تكلفة.", "Submitting a request creates no payment obligation. Our team will review it and contact you before discussing any cost.")}</p>
        </>}
      </div>

      <div className="mt-8 flex flex-wrap justify-between gap-3 border-t border-border pt-6">
        <Button type="button" variant="outline" onClick={back} disabled={step === 0}>{L("السابق", "Back")}</Button>
        {step < 6 ? <Button type="button" onClick={next}>{step === 5 ? L("مراجعة الطلب", "Review request") : L("التالي", "Next")}</Button>
          : <Button type="button" variant="gold" onClick={submit} disabled={busy}>{busy && <LoaderCircle className="animate-spin" />}{L("إرسال الطلب", "Submit request")}</Button>}
      </div>
    </div>
  );
}

function i18n(n: number, ar: boolean) { return ar ? n.toLocaleString("ar-EG") : String(n); }
