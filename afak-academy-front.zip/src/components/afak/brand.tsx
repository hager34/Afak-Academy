import { Link } from "@tanstack/react-router";
import logo from "@/assets/afak-logo.png";

export function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <Link to="/" className={`group inline-flex shrink-0 items-center ${footer ? "bg-background p-3" : ""}`} aria-label="Afak Academy — Home">
      <img
        src={logo}
        alt="Afak Academy"
        width={913}
        height={549}
        className={`${footer ? "h-20 w-auto" : "h-14 w-auto sm:h-16"} object-contain transition-transform duration-300 group-hover:-translate-y-0.5`}
      />
    </Link>
  );
}
