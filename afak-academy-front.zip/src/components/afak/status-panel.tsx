import type { ReactNode } from "react";
import { AlertTriangle, CheckCircle2, LoaderCircle, MailCheck } from "lucide-react";

type Tone = "loading" | "success" | "warning" | "info";
const icons = { loading: LoaderCircle, success: CheckCircle2, warning: AlertTriangle, info: MailCheck };
const colors = { loading: "text-brand-violet animate-spin", success: "text-brand-teal", warning: "text-destructive", info: "text-brand-violet" };

export function StatusPanel({ tone, title, children }: { tone: Tone; title: string; children?: ReactNode }) {
  const Icon = icons[tone];
  return (
    <section className="mx-auto max-w-2xl px-5 py-20">
      <div role={tone === "warning" ? "alert" : "status"} aria-live="polite" className="border border-border bg-card p-8 text-center md:p-12">
        <Icon className={`mx-auto size-12 ${colors[tone]}`} aria-hidden="true" />
        <h1 className="mt-5 font-display text-3xl md:text-4xl">{title}</h1>
        {children && <div className="mx-auto mt-4 grid max-w-lg gap-4 leading-7 text-muted-foreground">{children}</div>}
      </div>
    </section>
  );
}

export function DevNotice({ url, label }: { url?: string | undefined; label: string }) {
  if (!url || !import.meta.env.DEV) return null;
  return <p className="border border-dashed border-brand-gold bg-brand-gold-soft/40 p-3 text-start text-xs text-foreground">{label} <a className="break-all font-semibold underline" href={url}>{url}</a></p>;
}
