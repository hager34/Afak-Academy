import { SignatureV4 } from "@smithy/signature-v4";
import { Sha256 } from "@aws-crypto/sha256-js";

export const AWS_REGION = "us-east-1";

/** Reads ONLY AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY. Never logs values. */
export function loadAwsCredentials() {
  const accessKeyId = process.env["AWS_ACCESS_KEY_ID"]?.trim();
  const secretAccessKey = process.env["AWS_SECRET_ACCESS_KEY"]?.trim();
  if (!accessKeyId || !secretAccessKey) throw new Error("NOT_CONFIGURED");
  if (!/^A(KIA|SIA)[A-Z0-9]{16}$/.test(accessKeyId)) throw new Error("INVALID_ACCESS_KEY_ID_FORMAT");
  if (!/^[A-Za-z0-9/+]{40}$/.test(secretAccessKey)) throw new Error("INVALID_SECRET_ACCESS_KEY_FORMAT");
  return { accessKeyId, secretAccessKey };
}

/** Signs and sends a request with the official AWS SigV4 signer. */
export async function awsFetch(service: string, url: string, init: { method?: string; headers?: Record<string, string>; body?: string } = {}) {
  const u = new URL(url);
  const signer = new SignatureV4({ credentials: loadAwsCredentials(), region: AWS_REGION, service, sha256: Sha256 });
  const query: Record<string, string> = {};
  u.searchParams.forEach((v, k) => (query[k] = v));
  const signed = await signer.sign({
    method: init.method ?? "GET",
    protocol: u.protocol,
    hostname: u.hostname,
    path: u.pathname,
    query,
    headers: { host: u.hostname, ...(init.headers ?? {}) },
    body: init.body,
  });
  const { host: _h, ...headers } = signed.headers as Record<string, string>;
  return fetch(url, { method: signed.method, headers, body: init.body ?? null });
}
