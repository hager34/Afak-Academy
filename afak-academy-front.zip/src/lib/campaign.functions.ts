import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Ctx = { supabase: { rpc: (fn: "has_role", args: { _user_id: string; _role: "admin" }) => PromiseLike<{ data: boolean | null }> }; userId: string };

async function assertAdmin(context: Ctx) {
  const { data } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (!data) throw new Error("Forbidden");
}

export const getCampaignOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as unknown as Ctx);
    const m = await import("./campaign.server");
    const recipients = await m.eligibleRecipients();
    return {
      subject: m.SUBJECT,
      allowlist: m.ALLOWLIST,
      recipients: recipients.map((r) => r.email),
      preview: m.renderEmail(recipients[0]?.first_name ?? null),
      log: await m.sentLog(),
    };
  });

// Sends the test campaign (send-afak-test-campaign). Admin only, explicit confirmation required.
export const sendAfakTestCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ confirm: z.literal(true) }).parse(d))
  .handler(async ({ context }) => {
    await assertAdmin(context as unknown as Ctx);
    const m = await import("./campaign.server");
    try {
      return { ok: true as const, results: await m.sendCampaign() };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error && e.message === "NOT_CONFIGURED" ? "NOT_CONFIGURED" : "SERVER_ERROR" };
    }
  });
