import { CONFIRM_TOKEN_TTL_HOURS, PRIVACY_POLICY_VERSION, db, emailConfigured, queueEmail, randomToken, sha256, siteOrigin } from "./backend.server";

export type SubscribeResult = { ok: true; devConfirmUrl?: string | undefined };

async function logConsent(subscriber_id: string | null, email: string, consent_type: string, consent_status: string, source: string) {
  await db().from("consent_events").insert({ subscriber_id, email, consent_type, consent_status, policy_version: PRIVACY_POLICY_VERSION, source });
}

// Development-only: expose the confirmation link while SES is not connected. Never in production builds.
const devLink = (url: string) => (import.meta.env.DEV && !emailConfigured() ? url : undefined);

/** Starts (or restarts) Double Opt-in. Always returns a generic result. */
export async function startDoubleOptIn(email: string, language: "ar" | "en", source: string, firstName?: string): Promise<SubscribeResult> {
  const { data: existing } = await db().from("newsletter_subscribers").select("id,status").eq("email", email).maybeSingle();
  if (existing?.status === "SUBSCRIBED" || existing?.status === "SUPPRESSED") return { ok: true };

  const token = randomToken();
  const row = {
    email, preferred_language: language, status: "PENDING",
    confirmation_token_hash: await sha256(token),
    confirmation_expires_at: new Date(Date.now() + CONFIRM_TOKEN_TTL_HOURS * 3600_000).toISOString(),
    unsubscribed_at: null,
    ...(firstName ? { first_name: firstName } : {}),
  };
  const res = existing
    ? await db().from("newsletter_subscribers").update(row).eq("id", existing.id).select("id").single()
    : await db().from("newsletter_subscribers").insert(row).select("id").single();
  if (res.error || !res.data) { console.error("[newsletter] upsert failed", res.error?.code); throw new Error("SERVER_ERROR"); }
  const id = res.data.id;

  await logConsent(id, email, "NEWSLETTER", existing?.status === "UNSUBSCRIBED" ? "RESUBSCRIBE_REQUESTED" : "SUBSCRIPTION_REQUESTED", source);
  const url = `${siteOrigin()}/confirm-subscription?token=${token}`;
  await queueEmail({ email_type: "NEWSLETTER", recipient_email: email, template_key: "newsletter_confirmation", template_language: language, related_entity_type: "newsletter_subscriber", related_entity_id: id }, { confirmUrl: url });
  return { ok: true, devConfirmUrl: devLink(url) };
}

export async function resendConfirmation(email: string, language: "ar" | "en"): Promise<SubscribeResult> {
  const { data } = await db().from("newsletter_subscribers").select("id,status").eq("email", email).maybeSingle();
  if (data?.status !== "PENDING") return { ok: true };
  return startDoubleOptIn(email, language, "resend_confirmation"); // rotates the token
}

export type ConfirmResult = { status: "confirmed" | "already_confirmed" | "invalid" | "expired"; preferencesToken?: string };

export async function confirmToken(token: string): Promise<ConfirmResult> {
  const hash = await sha256(token);
  const { data: sub } = await db().from("newsletter_subscribers").select("id,email,status,confirmation_expires_at,preferred_language").eq("confirmation_token_hash", hash).maybeSingle();
  if (!sub) return { status: "invalid" };
  if (sub.status === "SUBSCRIBED") return { status: "already_confirmed" };
  if (sub.status !== "PENDING") return { status: "invalid" };
  if (!sub.confirmation_expires_at || new Date(sub.confirmation_expires_at).getTime() < Date.now()) return { status: "expired" };

  const prefToken = randomToken();
  const { error } = await db().from("newsletter_subscribers").update({ status: "SUBSCRIBED", confirmed_at: new Date().toISOString(), preferences_token_hash: await sha256(prefToken) }).eq("id", sub.id).eq("status", "PENDING");
  if (error) { console.error("[newsletter] confirm failed", error.code); throw new Error("SERVER_ERROR"); }

  const { data: topics } = await db().from("newsletter_topics").select("id").eq("active", true);
  if (topics?.length) await db().from("subscriber_topics").upsert(topics.map((t) => ({ subscriber_id: sub.id, topic_id: t.id, subscribed: true })));
  await logConsent(sub.id, sub.email, "NEWSLETTER", "CONFIRMED", "double_opt_in_link");
  const prefUrl = `${siteOrigin()}/email-preferences?token=${prefToken}`;
  await queueEmail({ email_type: "NEWSLETTER", recipient_email: sub.email, template_key: "newsletter_welcome", template_language: sub.preferred_language, related_entity_type: "newsletter_subscriber", related_entity_id: sub.id }, { preferencesUrl: prefUrl, unsubscribeUrl: `${siteOrigin()}/unsubscribe?token=${prefToken}` });
  return { status: "confirmed", preferencesToken: prefToken };
}

async function byPrefToken(token: string) {
  const { data } = await db().from("newsletter_subscribers").select("id,email,status,preferred_language").eq("preferences_token_hash", await sha256(token)).maybeSingle();
  return data;
}

export type PreferencesResult =
  | { status: "invalid" }
  | { status: "ok"; subscriberStatus: string; language: string; maskedEmail: string; topics: { slug: string; name_ar: string; name_en: string; subscribed: boolean }[] };

const mask = (e: string) => { const [u = "", d = ""] = e.split("@"); return `${u.slice(0, 2)}${"•".repeat(Math.max(1, u.length - 2))}@${d}`; };

export async function getPreferences(token: string): Promise<PreferencesResult> {
  const sub = await byPrefToken(token);
  if (!sub) return { status: "invalid" };
  const [{ data: topics }, { data: chosen }] = await Promise.all([
    db().from("newsletter_topics").select("id,slug,name_ar,name_en").eq("active", true).order("sort_order"),
    db().from("subscriber_topics").select("topic_id,subscribed").eq("subscriber_id", sub.id),
  ]);
  const on = new Map((chosen ?? []).map((c) => [c.topic_id, c.subscribed]));
  return { status: "ok", subscriberStatus: sub.status, language: sub.preferred_language, maskedEmail: mask(sub.email), topics: (topics ?? []).map((t) => ({ slug: t.slug, name_ar: t.name_ar, name_en: t.name_en, subscribed: sub.status === "SUBSCRIBED" && (on.get(t.id) ?? false) })) };
}

export async function updatePreferences(token: string, topicSlugs: string[], language: "ar" | "en"): Promise<{ status: "saved" | "invalid" | "not_subscribed" }> {
  const sub = await byPrefToken(token);
  if (!sub) return { status: "invalid" };
  if (sub.status !== "SUBSCRIBED") return { status: "not_subscribed" };
  const { data: topics } = await db().from("newsletter_topics").select("id,slug").eq("active", true);
  const now = new Date().toISOString();
  await db().from("subscriber_topics").upsert((topics ?? []).map((t) => ({ subscriber_id: sub.id, topic_id: t.id, subscribed: topicSlugs.includes(t.slug), updated_at: now })));
  await db().from("newsletter_subscribers").update({ preferred_language: language }).eq("id", sub.id);
  await logConsent(sub.id, sub.email, "NEWSLETTER", "PREFERENCES_UPDATED", "preferences_page");
  return { status: "saved" };
}

export async function unsubscribe(token: string): Promise<{ status: "unsubscribed" | "already_unsubscribed" | "invalid" }> {
  const sub = await byPrefToken(token);
  if (!sub) return { status: "invalid" };
  if (sub.status === "UNSUBSCRIBED" || sub.status === "SUPPRESSED") return { status: "already_unsubscribed" };
  await db().from("newsletter_subscribers").update({ status: "UNSUBSCRIBED", unsubscribed_at: new Date().toISOString(), confirmation_token_hash: null }).eq("id", sub.id);
  await db().from("subscriber_topics").update({ subscribed: false }).eq("subscriber_id", sub.id);
  await db().from("email_outbox").update({ status: "CANCELLED" }).eq("recipient_email", sub.email).eq("email_type", "NEWSLETTER").eq("status", "PENDING");
  await logConsent(sub.id, sub.email, "NEWSLETTER", "UNSUBSCRIBED", "unsubscribe_page");
  await queueEmail({ email_type: "TRANSACTIONAL", recipient_email: sub.email, template_key: "newsletter_unsubscribed", template_language: sub.preferred_language, related_entity_type: "newsletter_subscriber", related_entity_id: sub.id });
  return { status: "unsubscribed" };
}
