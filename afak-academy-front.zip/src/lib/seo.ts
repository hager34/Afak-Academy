// Shared head() builder so every route gets unique title/description, OG, Twitter, and canonical tags.
export function seo(path: string, title: string, description: string, extra: { noindex?: boolean } = {}) {
  return {
    meta: [
      { title }, { name: "description", content: description },
      { property: "og:title", content: title }, { property: "og:description", content: description },
      { property: "og:type", content: "website" }, { property: "og:url", content: `https://afakacademy.online${path}` },
      { name: "twitter:card", content: "summary_large_image" },
      ...(extra.noindex ? [{ name: "robots", content: "noindex" }] : []),
    ],
    links: [{ rel: "canonical", href: `https://afakacademy.online${path}` }],
  };
}
