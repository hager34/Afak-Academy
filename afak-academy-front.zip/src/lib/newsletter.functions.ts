// Public newsletter endpoints (Double Opt-in). Responses are generic and never reveal whether an email exists.
import { createServerFn } from "@tanstack/react-start";
import { preferencesSchema, subscribeSchema, tokenSchema } from "./validation";
import { rateLimit } from "./backend.server";
import * as nl from "./newsletter.server";

const RATE = { ok: false as const, error: "RATE_LIMITED" as const };

export const subscribeNewsletter = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => subscribeSchema.parse(d))
  .handler(async ({ data }) => {
    if (data.website) return { ok: true as const };
    if (!(await rateLimit("nl-subscribe", 3600, 5)) || !(await rateLimit("nl-subscribe-email", 3600, 3, data.email))) return RATE;
    return nl.startDoubleOptIn(data.email, data.language, "website_form", data.firstName || undefined);
  });

export const resendNewsletterConfirmation = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => subscribeSchema.pick({ email: true, language: true }).parse(d))
  .handler(async ({ data }) => {
    if (!(await rateLimit("nl-resend", 3600, 3, data.email))) return RATE;
    return nl.resendConfirmation(data.email, data.language);
  });

export const confirmNewsletter = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => tokenSchema.parse(d))
  .handler(async ({ data }) => {
    if (!(await rateLimit("nl-confirm", 600, 30))) return { status: "rate_limited" as const };
    return nl.confirmToken(data.token);
  });

export const getNewsletterPreferences = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => tokenSchema.parse(d))
  .handler(async ({ data }) => {
    if (!(await rateLimit("nl-prefs", 600, 60))) return { status: "invalid" as const };
    return nl.getPreferences(data.token);
  });

export const updateNewsletterPreferences = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => preferencesSchema.parse(d))
  .handler(async ({ data }) => {
    if (!(await rateLimit("nl-prefs-save", 600, 20))) return { status: "invalid" as const };
    return nl.updatePreferences(data.token, data.topics, data.language);
  });

export const unsubscribeNewsletter = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => tokenSchema.parse(d))
  .handler(async ({ data }) => {
    if (!(await rateLimit("nl-unsub", 600, 20))) return { status: "invalid" as const };
    return nl.unsubscribe(data.token);
  });
