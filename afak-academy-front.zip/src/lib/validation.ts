import { z } from "zod";
import { fields, services } from "@/content/services";

const email = z.string().trim().toLowerCase().email().max(255);
const phone = z.string().trim().max(30).regex(/^[+0-9()\s-]*$/).optional().or(z.literal(""));
const opt = (max: number) => z.string().trim().max(max).optional().or(z.literal(""));
export const newsletterSchema = z.object({ email });
export const contactSchema = z.object({
  name: z.string().trim().min(2).max(100), email, phone,
  subject: z.string().trim().min(3).max(120), message: z.string().trim().min(10).max(1500),
  consent: z.literal(true),
});

export const serviceTypes = services.map((s) => s.slug) as [string, ...string[]];
export const fieldSlugs = ["other", ...fields.map((f) => f.slug)] as [string, ...string[]];
export const levels = ["school", "undergraduate", "postgraduate", "professional", "other"] as const;
export const preferredLanguages = ["ar", "en", "both"] as const;
export const contactMethods = ["email", "whatsapp", "phone"] as const;

function deadlineOk(v: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const d = new Date(v + "T00:00:00Z").getTime();
  if (Number.isNaN(d)) return false;
  const today = Date.now() - 36 * 3600_000; // tolerate time zones
  return d >= today && d <= Date.now() + 2 * 365 * 86400_000;
}
const deadline = z.string().refine(deadlineOk);

// Per-step schemas for the multi-step service request form (client side).
export const requestSteps = [
  z.object({ service: z.enum(serviceTypes) }),
  z.object({ field: z.enum(fieldSlugs) }),
  z.object({ specialization: z.string().min(1).max(120), otherSpecialization: opt(120) }).refine((v) => v.specialization !== "other" || (v.otherSpecialization ?? "").trim().length >= 2, { path: ["otherSpecialization"] }),
  z.object({ institution: opt(150), level: z.enum(levels), subject: opt(150), title: opt(200), language: z.enum(preferredLanguages) }),
  z.object({ description: z.string().trim().min(20).max(3000), tasks: opt(1500), deadline, delivery: z.enum(contactMethods), budget: opt(60) }),
  z.object({ name: z.string().trim().min(2).max(100), email, phone, whatsapp: phone, country: z.string().trim().min(2).max(80), timezone: opt(80), consent: z.literal(true), newsletter: z.boolean().optional() }),
] as const;

// Full server-side schema: authoritative validation for POST service request.
export const serviceRequestSchema = z.object({
  service: z.enum(serviceTypes),
  field: z.enum(fieldSlugs),
  specialization: z.string().trim().min(1).max(120),
  otherSpecialization: opt(120),
  institution: opt(150), level: z.enum(levels), subject: opt(150), title: opt(200),
  language: z.enum(preferredLanguages),
  description: z.string().trim().min(20).max(3000), tasks: opt(1500), deadline,
  delivery: z.enum(contactMethods), budget: opt(60),
  name: z.string().trim().min(2).max(100), email, phone, whatsapp: phone,
  country: z.string().trim().min(2).max(80), timezone: opt(80),
  consent: z.literal(true), newsletter: z.boolean().default(false),
  uiLanguage: z.enum(["ar", "en"]).default("ar"),
  website: z.string().max(0).optional().or(z.literal("")), // honeypot, must stay empty
}).refine((v) => v.specialization !== "other" || (v.otherSpecialization ?? "").length >= 2, { path: ["otherSpecialization"] })
  .refine((v) => v.field === "other" || v.specialization === "other" || fields.find((f) => f.slug === v.field)?.specializations.some((s) => s.slug === v.specialization), { path: ["specialization"] });
export type ServiceRequestPayload = z.input<typeof serviceRequestSchema>;

export const tokenSchema = z.object({ token: z.string().min(20).max(100).regex(/^[A-Za-z0-9_-]+$/) });
export const subscribeSchema = z.object({ email, firstName: opt(100), language: z.enum(["ar", "en"]).default("ar"), website: z.string().max(0).optional().or(z.literal("")) });
export const preferencesSchema = tokenSchema.extend({ topics: z.array(z.string().max(40)).max(20), language: z.enum(["ar", "en"]) });
