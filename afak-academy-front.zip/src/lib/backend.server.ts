// Server-only helpers for the minimal Lovable Cloud backend.
// Never import from components; *.server.ts files are blocked from client bundles.
import { getRequestHeader } from "@tanstack/react-start/server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const PRIVACY_POLICY_VERSION = "2026-09-draft-1";
export const CONFIRM_TOKEN_TTL_HOURS = 48;

export const db = () => supabaseAdmin;

export function randomToken(bytes = 32) {
  const b = new Uint8Array(bytes);
  crypto.getRandomValues(b);
  return btoa(String.fromCharCode(...b)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export async function sha256(value: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(buf)).map((x) => x.toString(16).padStart(2, "0")).join("");
}

function clientIp() {
  try {
    return getRequestHeader("cf-connecting-ip") ?? getRequestHeader("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  } catch {
    return "unknown";
  }
}

/** Returns true when allowed. Keys use a hashed IP so raw IPs are never stored. */
export async function rateLimit(action: string, windowSeconds: number, max: number, extra = "") {
  const key = `${action}:${(await sha256(clientIp() + "|" + extra)).slice(0, 32)}`;
  const { data, error } = await db().rpc("hit_rate_limit", { _key: key, _window_seconds: windowSeconds, _max: max });
  if (error) { console.error("[rate-limit] check failed", error.code); return true; }
  return data === true;
}

export class PublicError extends Error {
  constructor(public code: "RATE_LIMITED" | "INVALID_INPUT" | "SERVER_ERROR") { super(code); }
}

export function siteOrigin() {
  try {
    const host = getRequestHeader("x-forwarded-host") ?? getRequestHeader("host");
    const proto = getRequestHeader("x-forwarded-proto") ?? (host?.startsWith("localhost") ? "http" : "https");
    if (host) return `${proto}://${host}`;
  } catch { /* ignore */ }
  return "https://afakacademy.online";
}

export function emailConfigured() {
  return Boolean(process.env["AWS_EMAIL_API_URL"] && process.env["AWS_EMAIL_API_AUTH_TOKEN"]);
}

type OutboxInput = {
  email_type: "TRANSACTIONAL" | "NEWSLETTER";
  recipient_email: string;
  template_key: string;
  template_language: string;
  related_entity_type: string;
  related_entity_id: string;
  suppressed?: boolean;
};

/**
 * Queue an email. `links` (e.g. confirmation URLs containing raw tokens) are passed to the
 * future AWS email API at dispatch time only and are never stored or logged.
 */
export async function queueEmail(input: OutboxInput, links: Record<string, string> = {}) {
  const { suppressed, ...row } = input;
  const { data, error } = await db().from("email_outbox").insert({ ...row, status: suppressed ? "SUPPRESSED" : "PENDING" }).select("id").single();
  if (error || !data) { console.error("[outbox] insert failed", error?.code); return; }
  if (suppressed) return;
  await dispatch(data.id, input, links);
}

// Boundary: Lovable server function -> AWS API Gateway -> Lambda -> Amazon SES.
async function dispatch(id: string, input: OutboxInput, links: Record<string, string>) {
  if (!emailConfigured()) {
    console.warn(`[outbox] AWS email API not configured (AWS_EMAIL_API_URL / AWS_EMAIL_API_AUTH_TOKEN). Job ${id} left PENDING.`);
    return;
  }
  try {
    const res = await fetch(process.env["AWS_EMAIL_API_URL"]!, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${process.env["AWS_EMAIL_API_AUTH_TOKEN"]}` },
      body: JSON.stringify({ outboxId: id, template: input.template_key, language: input.template_language, to: input.recipient_email, links }),
    });
    // Accepted by AWS is not "sent": SENT is set later from a verified SES delivery event.
    await db().from("email_outbox").update(res.ok ? { status: "PROCESSING", attempt_count: 1 } : { status: "FAILED", attempt_count: 1, last_error_code: `HTTP_${res.status}` }).eq("id", id);
  } catch {
    await db().from("email_outbox").update({ status: "FAILED", attempt_count: 1, last_error_code: "NETWORK" }).eq("id", id);
  }
}
