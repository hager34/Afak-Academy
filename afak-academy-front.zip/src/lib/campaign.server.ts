// Server-only: AWS SES test campaign. Credentials are read from backend secrets inside calls only.
import { awsFetch, loadAwsCredentials, AWS_REGION } from "./aws-signer.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { randomToken, sha256 } from "./backend.server";

export const CAMPAIGN_ID = "afak-test-campaign-2026-09";
export const SUBJECT = "دعم أكاديمي يساعدك على إنجاز مشروعك — Afak Academy";
export const ALLOWLIST = ["hagerelksas01@gmail.com", "seifabdelmaksoud1011@gmail.com"];
const SITE = "https://afakacademy.online";

const services = [
  ["المشاريع الجامعية", "University projects"],
  ["العروض التقديمية", "Presentations"],
  ["شرح المقررات الدراسية", "Course explanations"],
  ["التخصصات الهندسية", "Engineering disciplines"],
  ["الطب والمجالات الأكاديمية الأخرى", "Medicine and other academic fields"],
];

export function renderEmail(firstName?: string | null, unsubscribeUrl = `${SITE}/unsubscribe`) {
  const hello = firstName ? `مرحبًا ${escapeHtml(firstName)}،` : "مرحبًا،";
  const items = services.map(([ar, en]) => `<li style="margin:0 0 8px">${ar} <span style="color:#6b7280;font-size:13px">— ${en}</span></li>`).join("");
  const html = `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${SUBJECT}</title></head>
<body style="margin:0;background:#f4f1ea;font-family:Tahoma,Arial,sans-serif;color:#1f2937">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f1ea;padding:24px 12px"><tr><td align="center">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:12px;overflow:hidden">
<tr><td style="background:#16324f;color:#ffffff;padding:24px;text-align:right;font-size:22px;font-weight:bold">أكاديمية آفاق <span style="font-size:14px;font-weight:normal;opacity:.8">Afak Academy</span></td></tr>
<tr><td style="padding:28px 24px;text-align:right;line-height:1.8;font-size:16px">
<p style="margin:0 0 12px">${hello}</p>
<p style="margin:0 0 16px">في أكاديمية آفاق نساعدك على فهم مادتك وإنجاز عملك الأكاديمي بثقة، من خلال شرح عملي ومتابعة واضحة. نقدّم:</p>
<ul style="padding:0 20px 0 0;margin:0 0 20px">${items}</ul>
<p style="margin:0 0 24px">أرسل طلبك وسيتواصل معك فريقنا لمراجعته.</p>
<p style="text-align:center;margin:0 0 8px"><a href="${SITE}" style="display:inline-block;background:#c8792b;color:#ffffff;text-decoration:none;padding:14px 28px;border-radius:8px;font-weight:bold">زُر موقع أكاديمية آفاق</a></p>
</td></tr>
<tr><td style="padding:16px 24px;background:#f9fafb;color:#6b7280;font-size:12px;text-align:right;line-height:1.7">وصلتك هذه الرسالة لأنك وافقت على استلام تحديثات أكاديمية آفاق. للرد، راسلنا مباشرة على هذا البريد.<br><a href="${unsubscribeUrl}" style="color:#6b7280">إلغاء الاشتراك — Unsubscribe</a> · <a href="${SITE}" style="color:#6b7280">afakacademy.online</a></td></tr>
</table></td></tr></table></body></html>`;
  const text = `${firstName ? `مرحبًا ${firstName}،` : "مرحبًا،"}

في أكاديمية آفاق نساعدك على فهم مادتك وإنجاز عملك الأكاديمي بثقة. نقدّم:
${services.map(([ar, en]) => `- ${ar} (${en})`).join("\n")}

زُر موقعنا وأرسل طلبك: ${SITE}

وصلتك هذه الرسالة لأنك وافقت على استلام تحديثات أكاديمية آفاق.
إلغاء الاشتراك / Unsubscribe: ${unsubscribeUrl}`;
  return { html, text };
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

/** Eligible test recipients, intersected with the hard-coded allowlist. */
export async function eligibleRecipients() {
  const { data, error } = await supabaseAdmin
    .from("newsletter_subscribers")
    .select("id,email,first_name")
    .eq("eligible_to_send", true).eq("consent_status", "CONFIRMED")
    .eq("subscriber_status", "SUBSCRIBED").eq("status", "SUBSCRIBED").eq("is_test", true)
    .is("unsubscribed_at", null).is("suppressed_at", null);
  if (error) throw new Error("Could not load recipients");
  return (data ?? []).filter((r) => ALLOWLIST.includes(r.email.toLowerCase()));
}

export async function sentLog() {
  const { data } = await supabaseAdmin.from("campaign_sends").select("recipient_email,status,sent_at,safe_error_code").eq("campaign_id", CAMPAIGN_ID);
  return data ?? [];
}

export async function sendCampaign(onlyEmail?: string) {
  const from = "noreply@afakacademy.online";
  const replyTo = process.env["SES_REPLY_TO_EMAIL"] ?? "munjizacademy@gmail.com";
  const region = AWS_REGION;
  loadAwsCredentials(); // fail fast before claiming any rows
  const aws = { fetch: (url: string, init: { method?: string; headers?: Record<string, string>; body?: string }) => awsFetch("ses", url, init) };

  const results: { email: string; status: string; messageId?: string | undefined; error?: string; httpStatus?: number; requestId?: string | null }[] = [];
  const list = (await eligibleRecipients()).filter((r) => !onlyEmail || r.email.toLowerCase() === onlyEmail.toLowerCase());
  for (const r of list) {
    const email = r.email.toLowerCase();
    // Claim the row first; the unique (campaign_id, recipient_email) index blocks duplicates.
    const { data: claim, error: claimErr } = await supabaseAdmin.from("campaign_sends")
      .insert({ campaign_id: CAMPAIGN_ID, subscriber_id: r.id, recipient_email: email, status: "SENDING" })
      .select("id").single();
    if (claimErr || !claim) { results.push({ email, status: "ALREADY_SENT" }); continue; }

    // Fresh per-recipient unsubscribe token; only its hash is stored.
    const token = randomToken();
    await supabaseAdmin.from("newsletter_subscribers").update({ preferences_token_hash: await sha256(token) }).eq("id", r.id);
    const { html, text } = renderEmail(r.first_name, `${SITE}/unsubscribe?token=${token}`);
    try {
      const res = await aws.fetch(`https://email.${region}.amazonaws.com/v2/email/outbound-emails`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          FromEmailAddress: `Afak Academy <${from}>`,
          Destination: { ToAddresses: [email] }, // one recipient per message, never CC/BCC
          ReplyToAddresses: [replyTo],
          Content: { Simple: { Subject: { Data: SUBJECT, Charset: "UTF-8" }, Body: { Html: { Data: html, Charset: "UTF-8" }, Text: { Data: text, Charset: "UTF-8" } } } },
        }),
      });
      if (res.ok) {
        const body = (await res.json()) as { MessageId?: string };
        await supabaseAdmin.from("campaign_sends").update({ status: "SENT", ses_message_id: body.MessageId ?? null, sent_at: new Date().toISOString() }).eq("id", claim.id);
        results.push({ email, status: "SENT", messageId: body.MessageId });
      } else {
        // Store only the AWS error type, never the response body or credentials.
        const requestId = res.headers.get("x-amzn-requestid");
        const errType = res.headers.get("x-amzn-errortype");
        const raw = await res.text();
        let name = errType?.split(":")[0] ?? "", msg = raw;
        try { const b = JSON.parse(raw) as { __type?: string; name?: string; code?: string; message?: string; Message?: string }; name = b.__type ?? b.name ?? b.code ?? name; msg = b.message ?? b.Message ?? raw; } catch { /* non-JSON body */ }
        const code = `HTTP_${res.status} ${name}: ${msg} (RequestId ${requestId ?? "none"})`.slice(0, 600);
        await supabaseAdmin.from("campaign_sends").update({ status: "FAILED", safe_error_code: code }).eq("id", claim.id);
        console.error(`[campaign] SES rejected a message: ${code}`);
        results.push({ email, status: "FAILED", error: code, httpStatus: res.status, requestId });
      }
    } catch {
      await supabaseAdmin.from("campaign_sends").update({ status: "FAILED", safe_error_code: "NETWORK" }).eq("id", claim.id);
      results.push({ email, status: "FAILED" });
    }
  }
  return results;
}
