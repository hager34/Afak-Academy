import { fields, services, type Field, type Service } from "@/content/services";
import { submitServiceRequest } from "@/lib/requests.functions";
import {
  confirmNewsletter, getNewsletterPreferences, resendNewsletterConfirmation,
  subscribeNewsletter, unsubscribeNewsletter, updateNewsletterPreferences,
} from "@/lib/newsletter.functions";
import type { ServiceRequestPayload } from "@/lib/validation";

export type ApiResult = { ok: true; message: string };
const wait = (ms = 650) => new Promise((resolve) => setTimeout(resolve, ms));

// Single entry point the UI uses for backend access.
// Live (Lovable Cloud server functions): service requests + Double Opt-in newsletter.
// Still local: contact form (not in initial-phase scope). Auth, payments, uploads are postponed.
export const api = {
  submitServiceRequest: (data: ServiceRequestPayload) => submitServiceRequest({ data }),
  subscribeNewsletter: (data: { email: string; language: "ar" | "en"; website?: string }) => subscribeNewsletter({ data }),
  resendConfirmation: (data: { email: string; language: "ar" | "en" }) => resendNewsletterConfirmation({ data }),
  confirmNewsletter: (token: string) => confirmNewsletter({ data: { token } }),
  getPreferences: (token: string) => getNewsletterPreferences({ data: { token } }),
  updatePreferences: (data: { token: string; topics: string[]; language: "ar" | "en" }) => updateNewsletterPreferences({ data }),
  unsubscribe: (token: string) => unsubscribeNewsletter({ data: { token } }),
  async submitContact(_input: { name: string; email: string; phone?: string | undefined; subject: string; message: string; consent: boolean }): Promise<ApiResult> { await wait(); return { ok: true, message: "mock_contact_received" }; },
  async getServices(): Promise<Service[]> { return services; },
  async getFields(): Promise<Field[]> { return fields; },
};
