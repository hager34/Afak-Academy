export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      campaign_sends: {
        Row: {
          campaign_id: string
          created_at: string
          id: string
          recipient_email: string
          safe_error_code: string | null
          sent_at: string | null
          ses_message_id: string | null
          status: string
          subscriber_id: string | null
        }
        Insert: {
          campaign_id: string
          created_at?: string
          id?: string
          recipient_email: string
          safe_error_code?: string | null
          sent_at?: string | null
          ses_message_id?: string | null
          status?: string
          subscriber_id?: string | null
        }
        Update: {
          campaign_id?: string
          created_at?: string
          id?: string
          recipient_email?: string
          safe_error_code?: string | null
          sent_at?: string | null
          ses_message_id?: string | null
          status?: string
          subscriber_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "campaign_sends_subscriber_id_fkey"
            columns: ["subscriber_id"]
            isOneToOne: false
            referencedRelation: "newsletter_subscribers"
            referencedColumns: ["id"]
          },
        ]
      }
      consent_events: {
        Row: {
          consent_status: string
          consent_type: string
          created_at: string
          email: string
          id: string
          policy_version: string
          source: string
          subscriber_id: string | null
        }
        Insert: {
          consent_status: string
          consent_type: string
          created_at?: string
          email: string
          id?: string
          policy_version: string
          source: string
          subscriber_id?: string | null
        }
        Update: {
          consent_status?: string
          consent_type?: string
          created_at?: string
          email?: string
          id?: string
          policy_version?: string
          source?: string
          subscriber_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "consent_events_subscriber_id_fkey"
            columns: ["subscriber_id"]
            isOneToOne: false
            referencedRelation: "newsletter_subscribers"
            referencedColumns: ["id"]
          },
        ]
      }
      email_events: {
        Row: {
          created_at: string
          event_type: string
          id: string
          occurred_at: string
          provider_message_id: string
          recipient_email: string
          related_entity_id: string | null
          related_entity_type: string | null
        }
        Insert: {
          created_at?: string
          event_type: string
          id?: string
          occurred_at: string
          provider_message_id: string
          recipient_email: string
          related_entity_id?: string | null
          related_entity_type?: string | null
        }
        Update: {
          created_at?: string
          event_type?: string
          id?: string
          occurred_at?: string
          provider_message_id?: string
          recipient_email?: string
          related_entity_id?: string | null
          related_entity_type?: string | null
        }
        Relationships: []
      }
      email_outbox: {
        Row: {
          attempt_count: number
          created_at: string
          email_type: string
          id: string
          last_error_code: string | null
          recipient_email: string
          related_entity_id: string | null
          related_entity_type: string | null
          scheduled_at: string
          sent_at: string | null
          status: string
          template_key: string
          template_language: string
          updated_at: string
        }
        Insert: {
          attempt_count?: number
          created_at?: string
          email_type: string
          id?: string
          last_error_code?: string | null
          recipient_email: string
          related_entity_id?: string | null
          related_entity_type?: string | null
          scheduled_at?: string
          sent_at?: string | null
          status?: string
          template_key: string
          template_language?: string
          updated_at?: string
        }
        Update: {
          attempt_count?: number
          created_at?: string
          email_type?: string
          id?: string
          last_error_code?: string | null
          recipient_email?: string
          related_entity_id?: string | null
          related_entity_type?: string | null
          scheduled_at?: string
          sent_at?: string | null
          status?: string
          template_key?: string
          template_language?: string
          updated_at?: string
        }
        Relationships: []
      }
      newsletter_subscribers: {
        Row: {
          confirmation_expires_at: string | null
          confirmation_token_hash: string | null
          confirmed_at: string | null
          consent_date: string | null
          consent_source: string | null
          consent_status: string | null
          created_at: string
          eligible_to_send: boolean
          email: string
          first_name: string | null
          id: string
          is_test: boolean
          preferences_token_hash: string | null
          preferred_language: string
          status: string
          subscriber_status: string | null
          suppressed_at: string | null
          suppression_reason: string | null
          unsubscribed_at: string | null
          updated_at: string
        }
        Insert: {
          confirmation_expires_at?: string | null
          confirmation_token_hash?: string | null
          confirmed_at?: string | null
          consent_date?: string | null
          consent_source?: string | null
          consent_status?: string | null
          created_at?: string
          eligible_to_send?: boolean
          email: string
          first_name?: string | null
          id?: string
          is_test?: boolean
          preferences_token_hash?: string | null
          preferred_language?: string
          status?: string
          subscriber_status?: string | null
          suppressed_at?: string | null
          suppression_reason?: string | null
          unsubscribed_at?: string | null
          updated_at?: string
        }
        Update: {
          confirmation_expires_at?: string | null
          confirmation_token_hash?: string | null
          confirmed_at?: string | null
          consent_date?: string | null
          consent_source?: string | null
          consent_status?: string | null
          created_at?: string
          eligible_to_send?: boolean
          email?: string
          first_name?: string | null
          id?: string
          is_test?: boolean
          preferences_token_hash?: string | null
          preferred_language?: string
          status?: string
          subscriber_status?: string | null
          suppressed_at?: string | null
          suppression_reason?: string | null
          unsubscribed_at?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      newsletter_topics: {
        Row: {
          active: boolean
          created_at: string
          id: string
          name_ar: string
          name_en: string
          slug: string
          sort_order: number
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          name_ar: string
          name_en: string
          slug: string
          sort_order?: number
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          name_ar?: string
          name_en?: string
          slug?: string
          sort_order?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          country: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          preferred_language: string
          time_zone: string | null
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          country?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          phone?: string | null
          preferred_language?: string
          time_zone?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          country?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          preferred_language?: string
          time_zone?: string | null
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          hits: number
          key: string
          window_start: string
        }
        Insert: {
          hits?: number
          key: string
          window_start: string
        }
        Update: {
          hits?: number
          key?: string
          window_start?: string
        }
        Relationships: []
      }
      service_requests: {
        Row: {
          academic_field: string
          academic_level: string
          academic_specialization: string
          budget_range: string | null
          contact_consent: boolean
          country: string
          course_or_subject: string | null
          created_at: string
          deadline: string
          description: string
          email: string
          full_name: string
          id: string
          newsletter_opt_in_requested: boolean
          phone: string | null
          preferred_contact_method: string
          preferred_language: string
          privacy_policy_version: string
          request_number: string
          required_support: string | null
          service_type: string
          status: string
          time_zone: string | null
          title: string | null
          university: string | null
          updated_at: string
          user_id: string | null
          whatsapp: string | null
        }
        Insert: {
          academic_field: string
          academic_level: string
          academic_specialization: string
          budget_range?: string | null
          contact_consent: boolean
          country: string
          course_or_subject?: string | null
          created_at?: string
          deadline: string
          description: string
          email: string
          full_name: string
          id?: string
          newsletter_opt_in_requested?: boolean
          phone?: string | null
          preferred_contact_method: string
          preferred_language: string
          privacy_policy_version: string
          request_number?: string
          required_support?: string | null
          service_type: string
          status?: string
          time_zone?: string | null
          title?: string | null
          university?: string | null
          updated_at?: string
          user_id?: string | null
          whatsapp?: string | null
        }
        Update: {
          academic_field?: string
          academic_level?: string
          academic_specialization?: string
          budget_range?: string | null
          contact_consent?: boolean
          country?: string
          course_or_subject?: string | null
          created_at?: string
          deadline?: string
          description?: string
          email?: string
          full_name?: string
          id?: string
          newsletter_opt_in_requested?: boolean
          phone?: string | null
          preferred_contact_method?: string
          preferred_language?: string
          privacy_policy_version?: string
          request_number?: string
          required_support?: string | null
          service_type?: string
          status?: string
          time_zone?: string | null
          title?: string | null
          university?: string | null
          updated_at?: string
          user_id?: string | null
          whatsapp?: string | null
        }
        Relationships: []
      }
      subscriber_topics: {
        Row: {
          subscribed: boolean
          subscriber_id: string
          topic_id: string
          updated_at: string
        }
        Insert: {
          subscribed?: boolean
          subscriber_id: string
          topic_id: string
          updated_at?: string
        }
        Update: {
          subscribed?: boolean
          subscriber_id?: string
          topic_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriber_topics_subscriber_id_fkey"
            columns: ["subscriber_id"]
            isOneToOne: false
            referencedRelation: "newsletter_subscribers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriber_topics_topic_id_fkey"
            columns: ["topic_id"]
            isOneToOne: false
            referencedRelation: "newsletter_topics"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hit_rate_limit: {
        Args: { _key: string; _max: number; _window_seconds: number }
        Returns: boolean
      }
      next_request_number: { Args: never; Returns: string }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
