// Editable bilingual catalogue for Afak Academy services, academic fields, and specializations.
// Staff can add a field, specialization, service item, FAQ, or example here — pages update automatically.
import type { Localized } from "./site";

export type ServiceSlug = "courses" | "projects" | "presentations";
export type Service = {
  slug: ServiceSlug; icon: "courses" | "projects" | "presentations";
  title: Localized; short: Localized; intro: Localized; cta: Localized; items: Localized[]; note?: Localized;
};

const L = (ar: string, en: string): Localized => ({ ar, en });

export const services: Service[] = [
  {
    slug: "courses", icon: "courses",
    title: L("شرح المقررات الجامعية", "University Courses"),
    short: L("شرح مخصص ودروس تقوية لأي مقرر جامعي ضمن مجالاتنا الأكاديمية.", "Personalized explanation and tutoring for any university course within our academic fields."),
    intro: L("نساعدك على فهم مقرراتك الجامعية بعمق من خلال شرح منظم وأمثلة محلولة وخطة مراجعة تناسب مستواك ووقتك. لا نقتصر على قائمة مقررات ثابتة؛ يمكنك طلب الدعم في أي مقرر جامعي ضمن المجالات المتاحة.", "We help you truly understand your university courses through structured explanation, solved examples, and a revision plan that fits your level and schedule. There is no fixed course list — you can request support for any university course within the available academic fields."),
    cta: L("اطلب دعم مقرر", "Request Course Support"),
    items: [
      L("دروس فردية", "One-to-one tutoring"), L("جلسات لمجموعات صغيرة", "Small-group sessions"), L("شرح المقرر كاملاً", "Complete course explanation"),
      L("شرح فصول أو موضوعات محددة", "Specific chapters or topics"), L("حل أمثلة تعليمية", "Solving educational examples"), L("مراجعة التمارين وأسئلة التدريب", "Reviewing exercises and practice questions"),
      L("الاستعداد للامتحانات", "Exam preparation"), L("جلسات مراجعة", "Revision sessions"), L("خطط تعلم مخصصة", "Customized learning plans"),
      L("ورش عمل تطبيقية", "Practical workshops"), L("جلسات مباشرة أو مسجلة عبر الإنترنت", "Live or recorded online sessions"), L("الشرح بالعربية أو الإنجليزية حسب رغبتك", "Arabic or English explanation, as you prefer"),
    ],
  },
  {
    slug: "projects", icon: "projects",
    title: L("دعم وتطوير المشروعات", "Project Support and Mentoring"),
    short: L("إرشاد أكاديمي وتقني لمشروعاتك من الفكرة حتى العرض النهائي.", "Academic and technical guidance for your projects, from idea to final presentation."),
    intro: L("نرافقك في مراحل مشروعك الأكاديمي أو التقني: اختيار الفكرة والتخطيط والمنهجية والتنفيذ والمراجعة والتوثيق، حتى تفهم عملك جيداً وتعرضه بثقة.", "We support you through every stage of your academic or technical project — idea, planning, methodology, implementation, review, and documentation — so you understand your work and present it with confidence."),
    cta: L("اطلب دعم مشروع", "Request Project Support"),
    items: [
      L("اختيار فكرة المشروع", "Project idea selection"), L("تحديد الموضوع وصقله", "Topic refinement"), L("تخطيط المشروع", "Project planning"),
      L("تحليل المتطلبات", "Requirements analysis"), L("تخطيط البحث", "Research planning"), L("إرشاد منهجي", "Methodology guidance"),
      L("دعم التنفيذ التقني", "Technical implementation support"), L("إرشاد في البرمجة وتطوير البرمجيات", "Programming and software development guidance"), L("دعم التصميم الهندسي", "Engineering design support"),
      L("المحاكاة والنمذجة", "Simulations and modeling"), L("تحليل البيانات", "Data analysis"), L("تتبع الأخطاء والمراجعة التقنية", "Debugging and technical review"),
      L("هيكلة التوثيق", "Documentation structure"), L("إرشاد في إعداد التقارير", "Report preparation guidance"), L("التحضير لعرض المشروع", "Project presentation preparation"),
      L("الإشراف على مشروعات التخرج", "Graduation project mentoring"), L("مراجعة مشروع قائم وتحسينه", "Reviewing and improving an existing project"), L("تأهيلك لفهم العمل وعرضه بثقة", "Preparing you to understand and present the work confidently"),
    ],
    note: L("التزام بالنزاهة الأكاديمية: خدماتنا مصممة لدعم التعلم والفهم والتطوير التقني والعمل الأصيل. لا نضمن درجات، ولا نقدم أي عمل بهدف تسليمه على أنه عمل الطالب بما يخالف سياسات مؤسسته التعليمية.", "Academic integrity commitment: our services are designed to support learning, understanding, technical development, and original work. We do not promise grades, and we do not provide work intended to be submitted in violation of your institution’s policies."),
  },
  {
    slug: "presentations", icon: "presentations",
    title: L("العروض التقديمية الأكاديمية والمهنية", "Academic and Professional Presentations"),
    short: L("تصميم وتحسين عروض أكاديمية وعلمية وتقنية واضحة ومقنعة.", "Designing and improving clear, compelling academic, scientific, and technical presentations."),
    intro: L("نحوّل محتواك إلى عرض منظم بصرياً وسردياً، ونساعدك على تقديمه والإجابة عن الأسئلة بثقة.", "We turn your content into a visually and narratively organized presentation, and help you deliver it and answer questions with confidence."),
    cta: L("اطلب عرضاً تقديمياً", "Request a Presentation"),
    items: [
      L("عروض جامعية", "University presentations"), L("عروض هندسية", "Engineering presentations"), L("عروض طبية وعلمية", "Medical and scientific presentations"),
      L("عروض المشروعات", "Project presentations"), L("عروض مناقشة مشروع التخرج", "Graduation defense presentations"), L("عروض بحثية", "Research presentations"),
      L("عروض دراسات الحالة", "Case-study presentations"), L("الملصقات العلمية", "Poster presentations"), L("تصميم شرائح PowerPoint", "PowerPoint and slide design"),
      L("تنظيم المحتوى والقصة", "Organizing content and story"), L("التواصل البصري العلمي والتقني", "Scientific and technical visual communication"), L("الرسوم البيانية والمخططات والإنفوجرافيك", "Charts, diagrams, and infographics"),
      L("تنظيم الاستشهادات والمراجع", "Citation and reference organization"), L("تحسين بصري لشرائح قائمة", "Visual cleanup of existing slides"), L("ملاحظات المتحدث", "Speaker notes"),
      L("تدريب على الإلقاء", "Presentation delivery coaching"), L("التحضير للأسئلة والنقاش", "Preparing for questions and discussion"),
    ],
  },
];

export type Specialization = { slug: string; name: Localized };
export type Field = {
  slug: string; icon: "engineering" | "medicine" | "computing" | "business" | "sciences";
  name: Localized; description: Localized; specializations: Specialization[];
  examples: Localized[]; faqs: { q: Localized; a: Localized }[];
};

const spec = (slug: string, ar: string, en: string): Specialization => ({ slug, name: L(ar, en) });
const commonFaq = (fieldAr: string, fieldEn: string) => [
  { q: L(`هل تدعمون مقررات غير مذكورة في ${fieldAr}؟`, `Do you support courses not listed under ${fieldEn}?`), a: L("نعم. اختر «تخصص آخر» في نموذج الطلب واكتب اسم المقرر، وسنراجع الطلب ونوضح الخطوات المناسبة.", "Yes. Choose “Other specialization” in the request form and describe the course; we will review it and suggest the right next steps.") },
  { q: L("هل يمكن أن يكون الشرح بالإنجليزية؟", "Can explanations be in English?"), a: L("نعم، يمكنك اختيار العربية أو الإنجليزية أو كلتيهما عند تقديم الطلب.", "Yes, you can choose Arabic, English, or both when submitting your request.") },
  { q: L("كيف تُحدد التكلفة؟", "How is the cost determined?"), a: L("تُحدد بعد مراجعة الطلب بحسب نوع الخدمة وحجمها والموعد المطلوب. لا يتم تحصيل أي مبالغ عبر الموقع في هذه المرحلة.", "It is determined after reviewing your request, based on service type, scope, and deadline. No payment is collected through the website at this stage.") },
];

export const fields: Field[] = [
  {
    slug: "engineering", icon: "engineering", name: L("الهندسة", "Engineering"),
    description: L("دعم في المقررات والمشروعات والعروض عبر التخصصات الهندسية المختلفة، من الدوائر والتصميم الميكانيكي إلى الإنشاءات والطاقة.", "Support for courses, projects, and presentations across engineering disciplines — from circuits and mechanical design to structures and energy."),
    specializations: [
      spec("electrical", "الهندسة الكهربائية", "Electrical Engineering"), spec("electronics", "هندسة الإلكترونيات", "Electronics Engineering"), spec("communications", "هندسة الاتصالات", "Communications Engineering"),
      spec("computer", "هندسة الحاسبات", "Computer Engineering"), spec("mechanical", "الهندسة الميكانيكية", "Mechanical Engineering"), spec("mechatronics", "هندسة الميكاترونكس", "Mechatronics Engineering"),
      spec("robotics", "الروبوتات", "Robotics"), spec("civil", "الهندسة المدنية", "Civil Engineering"), spec("architecture", "العمارة", "Architecture"),
      spec("biomedical", "الهندسة الطبية الحيوية", "Biomedical Engineering"), spec("chemical", "الهندسة الكيميائية", "Chemical Engineering"), spec("industrial", "الهندسة الصناعية", "Industrial Engineering"),
      spec("production", "هندسة الإنتاج", "Production Engineering"), spec("automotive", "هندسة السيارات", "Automotive Engineering"), spec("renewable-energy", "هندسة الطاقة المتجددة", "Renewable Energy Engineering"),
      spec("aerospace", "هندسة الطيران والفضاء", "Aerospace Engineering"), spec("petroleum", "هندسة البترول", "Petroleum Engineering"),
    ],
    examples: [L("أحتاج إلى فهم مقرر الإلكترونيات الجامعي.", "I need help understanding a university electronics course."), L("أريد إعادة تصميم عرض مشروعي الهندسي.", "I need to redesign my engineering project presentation."), L("أحتاج إلى إرشاد في محاكاة دائرة لمشروع التخرج.", "I need guidance simulating a circuit for my graduation project.")],
    faqs: commonFaq("الهندسة", "Engineering"),
  },
  {
    slug: "medicine-health", icon: "medicine", name: L("الطب والعلوم الصحية", "Medicine and Health Sciences"),
    description: L("شرح مبسط ومنظم للمواد الطبية والصحية، ودعم في العروض العلمية والأبحاث والإحصاء الحيوي.", "Clear, structured explanation of medical and health subjects, plus support with scientific presentations, research, and biostatistics."),
    specializations: [
      spec("general-medicine", "الطب العام", "General Medicine"), spec("dentistry", "طب الأسنان", "Dentistry"), spec("pharmacy", "الصيدلة", "Pharmacy"),
      spec("nursing", "التمريض", "Nursing"), spec("physical-therapy", "العلاج الطبيعي", "Physical Therapy"), spec("public-health", "الصحة العامة", "Public Health"),
      spec("nutrition", "التغذية", "Nutrition"), spec("clinical-lab", "علوم المختبرات السريرية", "Clinical Laboratory Sciences"), spec("radiology", "الأشعة والتصوير الطبي", "Radiology and Medical Imaging"),
      spec("anatomy", "علم التشريح", "Anatomy"), spec("physiology", "علم وظائف الأعضاء", "Physiology"), spec("pathology", "علم الأمراض", "Pathology"),
      spec("pharmacology", "علم الأدوية", "Pharmacology"), spec("biomedical-sciences", "العلوم الطبية الحيوية", "Biomedical Sciences"), spec("medical-research", "البحث الطبي", "Medical Research"),
      spec("biostatistics", "الإحصاء الطبي والحيوي", "Medical Statistics and Biostatistics"),
    ],
    examples: [L("أحتاج إلى عرض طبي احترافي لندوة جامعية.", "I need a professional medical presentation for a university seminar."), L("أريد مراجعة منظمة لمقرر علم الأدوية قبل الامتحان.", "I want a structured pharmacology revision before my exam."), L("أحتاج إلى فهم التحليل الإحصائي في بحثي.", "I need help understanding the statistical analysis in my research.")],
    faqs: commonFaq("الطب والعلوم الصحية", "Medicine and Health Sciences"),
  },
  {
    slug: "computer-science", icon: "computing", name: L("علوم الحاسب والتقنية", "Computer Science and Technology"),
    description: L("من أساسيات البرمجة إلى الذكاء الاصطناعي والأمن السيبراني: شرح عملي ومراجعة للمشروعات البرمجية.", "From programming fundamentals to AI and cybersecurity: practical explanation and review of software projects."),
    specializations: [
      spec("programming", "البرمجة", "Programming"), spec("software-engineering", "هندسة البرمجيات", "Software Engineering"), spec("web-development", "تطوير الويب", "Web Development"),
      spec("mobile-development", "تطوير تطبيقات الهاتف", "Mobile Application Development"), spec("data-structures", "هياكل البيانات والخوارزميات", "Data Structures and Algorithms"), spec("databases", "قواعد البيانات", "Databases"),
      spec("data-science", "علم البيانات", "Data Science"), spec("ai", "الذكاء الاصطناعي", "Artificial Intelligence"), spec("machine-learning", "تعلم الآلة", "Machine Learning"),
      spec("cybersecurity", "الأمن السيبراني", "Cybersecurity"), spec("cloud", "الحوسبة السحابية", "Cloud Computing"), spec("networks", "شبكات الحاسب", "Computer Networks"),
      spec("embedded", "الأنظمة المدمجة", "Embedded Systems"), spec("information-systems", "نظم المعلومات", "Information Systems"), spec("ui-ux", "تصميم واجهات وتجربة المستخدم", "UI/UX Design"),
    ],
    examples: [L("أحتاج إلى مراجعة مشروعي البرمجي.", "I need help reviewing my programming project."), L("أريد شرحاً واضحاً لهياكل البيانات.", "I want a clear explanation of data structures."), L("أحتاج إلى تخطيط مشروع تخرج في تعلم الآلة.", "I need to plan a machine-learning graduation project.")],
    faqs: commonFaq("علوم الحاسب", "Computer Science"),
  },
  {
    slug: "business", icon: "business", name: L("إدارة الأعمال", "Business and Management"),
    description: L("دعم في المحاسبة والتمويل والتسويق والاقتصاد، ودراسات الحالة وعروض الأعمال.", "Support in accounting, finance, marketing, and economics, along with case studies and business presentations."),
    specializations: [
      spec("business-administration", "إدارة الأعمال", "Business Administration"), spec("accounting", "المحاسبة", "Accounting"), spec("finance", "التمويل", "Finance"),
      spec("marketing", "التسويق", "Marketing"), spec("economics", "الاقتصاد", "Economics"), spec("hr", "الموارد البشرية", "Human Resources"),
      spec("entrepreneurship", "ريادة الأعمال", "Entrepreneurship"), spec("project-management", "إدارة المشروعات", "Project Management"), spec("supply-chain", "إدارة سلاسل الإمداد", "Supply Chain Management"),
      spec("logistics", "الخدمات اللوجستية", "Logistics"), spec("business-analytics", "تحليلات الأعمال", "Business Analytics"),
    ],
    examples: [L("أحتاج إلى شرح مقرر المحاسبة المالية.", "I need an explanation of a financial accounting course."), L("أريد عرضاً احترافياً لدراسة حالة تسويقية.", "I want a professional presentation for a marketing case study.")],
    faqs: commonFaq("إدارة الأعمال", "Business"),
  },
  {
    slug: "sciences", icon: "sciences", name: L("العلوم الطبيعية والتطبيقية", "Natural and Applied Sciences"),
    description: L("شرح الرياضيات والإحصاء والفيزياء والكيمياء والأحياء بأسلوب يربط المفاهيم بالتطبيق.", "Mathematics, statistics, physics, chemistry, and biology explained in a way that connects concepts to application."),
    specializations: [
      spec("mathematics", "الرياضيات", "Mathematics"), spec("statistics", "الإحصاء", "Statistics"), spec("physics", "الفيزياء", "Physics"),
      spec("chemistry", "الكيمياء", "Chemistry"), spec("biology", "الأحياء", "Biology"), spec("biotechnology", "التقنية الحيوية", "Biotechnology"),
      spec("environmental-science", "علوم البيئة", "Environmental Science"),
    ],
    examples: [L("أحتاج إلى حل أمثلة في التفاضل والتكامل.", "I need help solving calculus examples."), L("أريد مراجعة مقرر الكيمياء العضوية قبل الامتحان.", "I want to revise organic chemistry before my exam.")],
    faqs: commonFaq("العلوم", "Sciences"),
  },
];

export const exampleRequests: { text: Localized; service: ServiceSlug; field: string }[] = [
  { text: L("أحتاج إلى فهم مقرر الإلكترونيات الجامعي.", "I need help understanding a university electronics course."), service: "courses", field: "engineering" },
  { text: L("أحتاج إلى دعم في تخطيط وتنفيذ مشروع تخرجي.", "I need support planning and implementing my graduation project."), service: "projects", field: "engineering" },
  { text: L("أحتاج إلى عرض طبي احترافي لندوة جامعية.", "I need a professional medical presentation for a university seminar."), service: "presentations", field: "medicine-health" },
  { text: L("أحتاج إلى مراجعة مشروعي البرمجي.", "I need help reviewing my programming project."), service: "projects", field: "computer-science" },
  { text: L("أحتاج إلى إعادة تصميم عرض مشروعي الهندسي.", "I need to redesign my engineering project presentation."), service: "presentations", field: "engineering" },
];

export const howItWorks: { title: Localized; text: Localized }[] = [
  { title: L("اختر مجالك الأكاديمي", "Choose your academic field"), text: L("الهندسة أو الطب أو الحاسب أو الأعمال أو العلوم.", "Engineering, medicine, computing, business, or sciences.") },
  { title: L("حدد تخصصك", "Select your specialization"), text: L("اختر تخصصك الدقيق أو اكتب تخصصاً آخر.", "Pick your exact specialization, or describe another one.") },
  { title: L("اختر نوع الخدمة", "Choose a service"), text: L("شرح مقررات أو دعم مشروعات أو عروض تقديمية.", "Courses, Projects, or Presentations.") },
  { title: L("صف احتياجك وموعدك", "Describe your needs and deadline"), text: L("اشرح المطلوب بالتفصيل وحدد الموعد المناسب.", "Explain what you need in detail and set your deadline.") },
  { title: L("استلم خطة مخصصة", "Receive a customized plan"), text: L("نراجع طلبك ونرسل لك الخطوات التالية وخطة تناسبك.", "We review your request and send the next steps and a plan tailored to you.") },
];

export const benefits: Localized[] = [
  L("دعم أكاديمي متعدد التخصصات", "Multidisciplinary academic support"), L("خدمات مخصصة لكل طلب", "Customized services for every request"),
  L("دعم بالعربية والإنجليزية", "Arabic and English support"), L("سير عمل واضح ومنظم", "A clear, organized workflow"),
  L("دعم لمستويات أكاديمية مختلفة", "Support for different academic levels"), L("تواصل ومتابعة عبر الإنترنت", "Online communication and follow-up"),
  L("تركيز على الفهم والجودة والعمل الأصيل", "A focus on understanding, quality, and original work"),
];

export const generalFaqs = [
  { q: L("هل يمكنني طلب دعم في مقرر غير مذكور؟", "Can I request support for a course that is not listed?"), a: L("نعم. نعرض المجالات والتخصصات للتوضيح فقط، ويمكنك طلب الدعم في أي مقرر جامعي ضمن مجالاتنا.", "Yes. Fields and specializations are shown for guidance; you can request support for any university course within our fields.") },
  { q: L("هل تضمنون درجات معينة؟", "Do you guarantee grades?"), a: L("لا. نركز على الفهم والجودة والعمل الأصيل، ولا نقدم وعوداً بنتائج أو درجات.", "No. We focus on understanding, quality, and original work, and we make no promises about results or grades.") },
  { q: L("هل يتم الدفع عبر الموقع؟", "Is payment collected on the website?"), a: L("لا، لا يتم تحصيل أي مبالغ عبر الموقع حالياً؛ نتواصل معك أولاً بعد مراجعة الطلب.", "No payment is collected through the website at this stage.") },
];

export const getField = (slug: string) => fields.find((f) => f.slug === slug);
export const getService = (slug: string) => services.find((s) => s.slug === slug);
