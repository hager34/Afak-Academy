export type Lang = "ar" | "en";
export type Localized = Record<Lang, string>;
export const t = (value: Localized, lang: Lang) => value[lang];

export const contact = {
  email: "hello@afakacademy.online",
  phone: "+201550514323",
  hours: { ar: "مواعيد نموذجية: الأحد–الخميس، ٩ ص–٥ م", en: "Sample hours: Sun–Thu, 9am–5pm" },
};

