create type public.app_role as enum ('admin', 'user');
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Own roles read" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path to 'public' as $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name'))
  ON CONFLICT (id) DO NOTHING;
  -- Project owner becomes the only admin (sign-in still requires a verified email).
  IF lower(NEW.email) = 'hagerelksas01@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin') ON CONFLICT DO NOTHING;
  END IF;
  RETURN NEW;
END; $$;

create table public.campaign_sends (
  id uuid primary key default gen_random_uuid(),
  campaign_id text not null,
  subscriber_id uuid references public.newsletter_subscribers(id),
  recipient_email text not null,
  status text not null default 'PENDING',
  ses_message_id text,
  safe_error_code text,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  unique (campaign_id, recipient_email)
);
grant all on public.campaign_sends to service_role;
alter table public.campaign_sends enable row level security;