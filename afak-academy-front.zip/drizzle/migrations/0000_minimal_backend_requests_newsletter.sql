
create sequence public.service_request_seq;

create or replace function public.update_updated_at() returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end $$;

create or replace function public.next_request_number() returns text language sql volatile set search_path = public as $$
  select 'AFAK-' || to_char(now() at time zone 'utc','YYYY') || '-' || lpad(nextval('public.service_request_seq')::text, 6, '0')
$$;

create table public.service_requests (
  id uuid primary key default gen_random_uuid(),
  request_number text not null unique default public.next_request_number(),
  service_type text not null check (service_type in ('courses','projects','presentations')),
  academic_field text not null check (char_length(academic_field) <= 80),
  academic_specialization text not null check (char_length(academic_specialization) <= 120),
  academic_level text not null check (academic_level in ('school','undergraduate','postgraduate','professional','other')),
  university text check (char_length(university) <= 150),
  course_or_subject text check (char_length(course_or_subject) <= 150),
  title text check (char_length(title) <= 200),
  description text not null check (char_length(description) between 20 and 3000),
  required_support text check (char_length(required_support) <= 1500),
  preferred_language text not null check (preferred_language in ('ar','en','both')),
  deadline date not null,
  preferred_contact_method text not null check (preferred_contact_method in ('email','whatsapp','phone')),
  budget_range text check (char_length(budget_range) <= 60),
  full_name text not null check (char_length(full_name) between 2 and 100),
  email text not null check (char_length(email) <= 255),
  phone text check (char_length(phone) <= 30),
  whatsapp text check (char_length(whatsapp) <= 30),
  country text not null check (char_length(country) <= 80),
  time_zone text check (char_length(time_zone) <= 80),
  contact_consent boolean not null check (contact_consent = true),
  newsletter_opt_in_requested boolean not null default false,
  privacy_policy_version text not null,
  status text not null default 'NEW' check (status in ('NEW','REVIEWED','CONTACTED','CLOSED')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant all on public.service_requests to service_role;
alter table public.service_requests enable row level security;
create trigger trg_sr_updated before update on public.service_requests for each row execute function public.update_updated_at();

create table public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  first_name text check (char_length(first_name) <= 100),
  status text not null default 'PENDING' check (status in ('PENDING','SUBSCRIBED','UNSUBSCRIBED','SUPPRESSED')),
  preferred_language text not null default 'ar' check (preferred_language in ('ar','en')),
  confirmation_token_hash text unique,
  confirmation_expires_at timestamptz,
  preferences_token_hash text unique,
  confirmed_at timestamptz,
  unsubscribed_at timestamptz,
  suppressed_at timestamptz,
  suppression_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant all on public.newsletter_subscribers to service_role;
alter table public.newsletter_subscribers enable row level security;
create trigger trg_ns_updated before update on public.newsletter_subscribers for each row execute function public.update_updated_at();

create table public.newsletter_topics (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_ar text not null,
  name_en text not null,
  sort_order int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
grant all on public.newsletter_topics to service_role;
alter table public.newsletter_topics enable row level security;
insert into public.newsletter_topics (slug,name_ar,name_en,sort_order) values
('courses','المقررات','Courses',1),
('projects','المشاريع','Projects',2),
('presentations','العروض التقديمية','Presentations',3),
('engineering','الهندسة','Engineering',4),
('medicine-health','الطب والعلوم الصحية','Medicine and Health Sciences',5),
('computer-science','علوم الحاسب والتقنية','Computer Science and Technology',6),
('business','إدارة الأعمال','Business and Management',7),
('sciences','العلوم الطبيعية والتطبيقية','Natural and Applied Sciences',8),
('announcements','إعلانات الأكاديمية العامة','General Academy Announcements',9);

create table public.subscriber_topics (
  subscriber_id uuid not null references public.newsletter_subscribers(id) on delete cascade,
  topic_id uuid not null references public.newsletter_topics(id) on delete cascade,
  subscribed boolean not null default true,
  updated_at timestamptz not null default now(),
  primary key (subscriber_id, topic_id)
);
grant all on public.subscriber_topics to service_role;
alter table public.subscriber_topics enable row level security;

create table public.consent_events (
  id uuid primary key default gen_random_uuid(),
  subscriber_id uuid references public.newsletter_subscribers(id) on delete set null,
  email text not null,
  consent_type text not null,
  consent_status text not null,
  policy_version text not null,
  source text not null,
  created_at timestamptz not null default now()
);
grant all on public.consent_events to service_role;
alter table public.consent_events enable row level security;

create table public.email_outbox (
  id uuid primary key default gen_random_uuid(),
  email_type text not null check (email_type in ('TRANSACTIONAL','NEWSLETTER')),
  recipient_email text not null,
  template_key text not null,
  template_language text not null default 'ar',
  related_entity_type text,
  related_entity_id uuid,
  status text not null default 'PENDING' check (status in ('PENDING','PROCESSING','SENT','FAILED','CANCELLED','SUPPRESSED')),
  attempt_count int not null default 0,
  scheduled_at timestamptz not null default now(),
  sent_at timestamptz,
  last_error_code text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant all on public.email_outbox to service_role;
alter table public.email_outbox enable row level security;
create trigger trg_eo_updated before update on public.email_outbox for each row execute function public.update_updated_at();

create table public.email_events (
  id uuid primary key default gen_random_uuid(),
  provider_message_id text not null,
  event_type text not null check (event_type in ('DELIVERY','BOUNCE','COMPLAINT','REJECT','DELIVERY_DELAY','UNSUBSCRIBE')),
  recipient_email text not null,
  related_entity_type text,
  related_entity_id uuid,
  occurred_at timestamptz not null,
  created_at timestamptz not null default now(),
  unique (provider_message_id, event_type, recipient_email)
);
grant all on public.email_events to service_role;
alter table public.email_events enable row level security;

create table public.rate_limits (
  key text not null,
  window_start timestamptz not null,
  hits int not null default 1,
  primary key (key, window_start)
);
grant all on public.rate_limits to service_role;
alter table public.rate_limits enable row level security;

create or replace function public.hit_rate_limit(_key text, _window_seconds int, _max int) returns boolean
language plpgsql security definer set search_path = public as $$
declare w timestamptz := to_timestamp(floor(extract(epoch from now()) / _window_seconds) * _window_seconds); n int;
begin
  insert into public.rate_limits(key, window_start) values (_key, w)
  on conflict (key, window_start) do update set hits = rate_limits.hits + 1 returning hits into n;
  delete from public.rate_limits where window_start < now() - interval '1 day';
  return n <= _max;
end $$;
revoke all on function public.hit_rate_limit(text,int,int) from public, anon, authenticated;
grant execute on function public.hit_rate_limit(text,int,int) to service_role;
revoke all on function public.next_request_number() from public, anon, authenticated;
grant usage on sequence public.service_request_seq to service_role;
