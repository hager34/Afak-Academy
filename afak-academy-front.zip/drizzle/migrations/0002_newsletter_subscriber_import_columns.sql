ALTER TABLE public.newsletter_subscribers
  ADD COLUMN IF NOT EXISTS subscriber_status text,
  ADD COLUMN IF NOT EXISTS consent_status text,
  ADD COLUMN IF NOT EXISTS consent_date timestamptz,
  ADD COLUMN IF NOT EXISTS consent_source text,
  ADD COLUMN IF NOT EXISTS eligible_to_send boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS is_test boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS newsletter_subscribers_email_lower_key ON public.newsletter_subscribers (lower(email));