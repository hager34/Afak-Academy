<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep all editable bilingual academy copy and mock catalog data centralized in `src/content/site.ts` so staff changes never require component logic edits.
- Keep external service access behind `src/services/api.ts`; the frontend uses local mocks until the future AWS API is explicitly connected.
- Keep Arabic as the stable SSR default and restore the user's language after hydration to prevent directionality hydration mismatches.
- Services, academic fields, specializations, examples, and FAQs live in `src/content/services.ts`; field and service pages plus the request form derive from it so staff edits never touch components.
- Backend = Lovable Cloud server functions in `src/lib/*.functions.ts` with server-only helpers in `*.server.ts`; operational tables deny public access and are only touched via the service-role client inside handlers.
- Accounts are optional (email + Google): `profiles` and own `service_requests` rows are readable by the owner via RLS; requests stay submittable without an account and are linked to `user_id` when a bearer token is present.
- Email sending goes only through `queueEmail` (email_outbox) → future AWS SES API; never mark SENT without a provider event.
- Admin-only AWS SES test campaign lives in src/lib/campaign.*; roles via user_roles/has_role; owner email auto-granted admin in handle_new_user.
- Use the approved Afak logo unchanged; the visual system is white-led with deep blue, medium blue, and restrained warm-gold accents to match it.
